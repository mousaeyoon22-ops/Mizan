using System.Globalization;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using Mizan.Domain.Accessibility;

namespace Mizan.Application.Accessibility;

/// <summary>
/// Bilingual (Arabic + English) Deterministic Voice Command Parser & Financial Safety Gate:
/// - Read-only queries execute immediately with TTS read-back + visual captions.
/// - Financial mutations ALWAYS enter `DraftAwaitingConfirm` (NEVER auto-posted from raw speech).
/// - High-value financial commands (>= profile.VoiceHighValueThreshold) require PIN/Biometric confirmation.
/// - All terminal voice records are immutable and SHA-256 hashed for auditing.
/// </summary>
public sealed class VoiceCommandGovernanceService
{
    private readonly Dictionary<(Guid OrgId, string Key), VoiceCommandRecord> _idempotencyStore = new();
    private readonly Dictionary<Guid, VoiceCommandRecord> _records = new();

    private static readonly Regex NumberPattern = new(@"(?<num>\d+(?:[.,]\d{1,4})?)", RegexOptions.Compiled);

    public VoiceCommandRecord ProcessTranscript(
        Guid orgId, Guid userId, string idempotencyKey, string transcript, string lang, UserAccessibilityProfile profile)
    {
        if (_idempotencyStore.TryGetValue((orgId, idempotencyKey), out var existing))
            return existing;

        var normalized = NormalizeArabicDigits(transcript.Trim());
        var hash = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(normalized))).ToLowerInvariant();
        var (intent, isMutation, amount, currency) = ParseDeterministicIntent(normalized);

        VoiceCommandState initialState;
        string readBackAr, readBackEn;

        if (intent == VoiceIntent.Unknown || (isMutation && (amount is null || amount <= 0m)))
        {
            initialState = VoiceCommandState.RejectedAmbiguous;
            readBackAr = "لم يتم فهم الأمر المالي أو المبلغ بدقة. يرجى إعادة النطق بوضوح مع ذكر المبلغ والعملة.";
            readBackEn = "Financial command or amount was ambiguous. Please repeat clearly with amount and currency.";
        }
        else if (!isMutation)
        {
            initialState = VoiceCommandState.ExecutedReadOnly;
            readBackAr = $"تم تنفيذ الاستعلام: {intent}.";
            readBackEn = $"Query executed: {intent}.";
        }
        else
        {
            initialState = VoiceCommandState.DraftAwaitingConfirm;
            var requiresPin = amount!.Value >= profile.VoiceHighValueThreshold;
            readBackAr = requiresPin
                ? $"مسودة {intent} بمبلغ {amount:0.00} {currency}. المبلغ يتجاوز الحد؛ يرجى التأكيد برمز PIN أو البصمة للترحيل."
                : $"مسودة {intent} بمبلغ {amount:0.00} {currency}. قل (تأكيد الترحيل) أو اضغط زر التأكيد للإتمام، أو قل (إلغاء).";
            readBackEn = requiresPin
                ? $"Draft {intent} for {amount:0.00} {currency}. High-value threshold reached; confirm with PIN or Biometric."
                : $"Draft {intent} for {amount:0.00} {currency}. Say 'Confirm Post' or tap Confirm, or say 'Cancel'.";
        }

        var record = new VoiceCommandRecord
        {
            OrgId = orgId,
            UserId = userId,
            IdempotencyKey = idempotencyKey,
            CommandLang = lang.ToLowerInvariant(),
            RawTranscript = normalized,
            TranscriptSha256 = hash,
            Intent = intent,
            IsFinancialMutation = isMutation,
            AmountValue = amount,
            Currency = currency,
            ReadBackPromptAr = readBackAr,
            ReadBackPromptEn = readBackEn,
            State = initialState
        };

        _records[record.Id] = record;
        _idempotencyStore[(orgId, idempotencyKey)] = record;
        return record;
    }

    public VoiceCommandRecord ConfirmDraft(
        Guid orgId, Guid userId, Guid commandId, VoiceConfirmationMethod method,
        UserAccessibilityProfile profile, Guid postedJournalId)
    {
        if (!_records.TryGetValue(commandId, out var rec) || rec.OrgId != orgId || rec.UserId != userId)
            throw new UnauthorizedAccessException("BOLA Blocked: Voice command draft not found for caller.");

        if (rec.State != VoiceCommandState.DraftAwaitingConfirm)
            throw new InvalidOperationException($"VOICE_STATE_VIOLATION: Command is in state {rec.State}, not DraftAwaitingConfirm.");

        if (rec.AmountValue.HasValue && rec.AmountValue.Value >= profile.VoiceHighValueThreshold
            && method != VoiceConfirmationMethod.PinOrBiometric)
        {
            throw new InvalidOperationException("HIGH_VALUE_VOICE_REQUIRES_PIN_OR_BIOMETRIC");
        }

        rec.State = VoiceCommandState.ConfirmedAndPosted;
        rec.ConfirmationMethod = method;
        rec.LinkedJournalId = postedJournalId;
        rec.ConfirmedAt = DateTimeOffset.UtcNow;
        return rec;
    }

    public VoiceCommandRecord CancelDraft(Guid orgId, Guid userId, Guid commandId)
    {
        if (!_records.TryGetValue(commandId, out var rec) || rec.OrgId != orgId || rec.UserId != userId)
            throw new UnauthorizedAccessException("BOLA Blocked: Voice command draft not found for caller.");

        if (rec.State != VoiceCommandState.DraftAwaitingConfirm)
            throw new InvalidOperationException("VOICE_AUDIT_IMMUTABILITY_VIOLATION: Cannot cancel non-draft voice command.");

        rec.State = VoiceCommandState.CancelledByUser;
        rec.ConfirmedAt = DateTimeOffset.UtcNow;
        return rec;
    }

    private static (VoiceIntent Intent, bool IsMutation, decimal? Amount, string Currency) ParseDeterministicIntent(string text)
    {
        var lower = text.ToLowerInvariant();
        string currency = "USD";
        if (lower.Contains("ريال سعودي") || lower.Contains("sar")) currency = "SAR";
        else if (lower.Contains("ريال يمني") || lower.Contains("yer")) currency = "YER";
        else if (lower.Contains("درهم") || lower.Contains("aed")) currency = "AED";
        else if (lower.Contains("يورو") || lower.Contains("eur")) currency = "EUR";
        else if (lower.Contains("دولار") || lower.Contains("usd") || lower.Contains("$")) currency = "USD";

        decimal? amount = null;
        var m = NumberPattern.Match(lower);
        if (m.Success && decimal.TryParse(m.Groups["num"].Value.Replace(',', '.'), NumberStyles.Number, CultureInfo.InvariantCulture, out var parsed))
            amount = Math.Round(parsed, 4, MidpointRounding.AwayFromZero);

        if (lower.Contains("رصيد") || lower.Contains("balance"))
            return (VoiceIntent.QueryBalance, false, null, currency);
        if (lower.Contains("مخزون") || lower.Contains("stock") || lower.Contains("كمية"))
            return (VoiceIntent.QueryStock, false, null, currency);
        if (lower.Contains("اقرأ آخر فاتورة") || lower.Contains("read last invoice"))
            return (VoiceIntent.ReadLastInvoice, false, null, currency);
        if (lower.Contains("افتح شاشة") || lower.Contains("اذهب إلى") || lower.Contains("open screen") || lower.Contains("navigate"))
            return (VoiceIntent.Navigate, false, null, currency);

        if (lower.Contains("فاتورة بيع") || lower.Contains("بيع") || lower.Contains("sale invoice") || lower.Contains("sell"))
            return (VoiceIntent.CreateSaleInvoice, true, amount, currency);
        if (lower.Contains("سند قبض") || lower.Contains("قبض") || lower.Contains("receive cash") || lower.Contains("receipt"))
            return (VoiceIntent.RecordCashReceipt, true, amount, currency);
        if (lower.Contains("سند صرف") || lower.Contains("صرف") || lower.Contains("pay cash") || lower.Contains("expense"))
            return (VoiceIntent.RecordCashPayment, true, amount, currency);

        return (VoiceIntent.Unknown, false, amount, currency);
    }

    private static string NormalizeArabicDigits(string input)
    {
        var sb = new StringBuilder(input.Length);
        foreach (var ch in input)
        {
            sb.Append(ch switch
            {
                '٠' => '0', '١' => '1', '٢' => '2', '٣' => '3', '٤' => '4',
                '٥' => '5', '٦' => '6', '٧' => '7', '٨' => '8', '٩' => '9',
                _ => ch
            });
        }
        return sb.ToString();
    }
}
