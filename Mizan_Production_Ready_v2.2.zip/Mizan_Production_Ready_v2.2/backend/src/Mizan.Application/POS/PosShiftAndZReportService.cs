using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Mizan.Domain.Entities;
using Mizan.Domain.POS;

namespace Mizan.Application.POS;

/// <summary>
/// Manages Multi-Cashier Shifts, Variant-Level Sales, Blind Cash Close, Immutable Z-Reports,
/// and automatic Double-Entry posting for Cash Shortage/Overage variances (0.0000 trial balance variance).
/// </summary>
public sealed class PosShiftAndZReportService
{
    private readonly List<PosShift> _shifts = new();
    private readonly List<JournalEntry> _varianceLedger = new();

    public IReadOnlyList<JournalEntry> VarianceLedger => _varianceLedger.AsReadOnly();

    private static decimal R4(decimal v) => Math.Round(v, 4, MidpointRounding.AwayFromZero);

    public PosShift OpenShift(Guid orgId, Guid terminalId, Guid cashierUserId, decimal openingFloat, string currency)
    {
        if (openingFloat < 0m) throw new ArgumentOutOfRangeException(nameof(openingFloat));

        if (_shifts.Any(s => s.OrgId == orgId && s.TerminalId == terminalId && s.Status == ShiftStatus.Open))
            throw new InvalidOperationException("SHIFT_CONFLICT: Terminal already has an active OPEN shift.");

        if (_shifts.Any(s => s.OrgId == orgId && s.CashierUserId == cashierUserId && s.Status == ShiftStatus.Open))
            throw new InvalidOperationException("SHIFT_CONFLICT: Cashier already has an active OPEN shift.");

        var shift = new PosShift
        {
            OrgId = orgId,
            TerminalId = terminalId,
            CashierUserId = cashierUserId,
            OpeningFloat = R4(openingFloat),
            Currency = currency.ToUpperInvariant(),
            Status = ShiftStatus.Open
        };
        _shifts.Add(shift);
        return shift;
    }

    public void RecordVariantSale(
        PosShift shift, ItemVariant variant, decimal qty, int expectedRowVersion,
        decimal cashPaid, decimal cardPaid, decimal creditAmount)
    {
        if (shift.Status != ShiftStatus.Open)
            throw new InvalidOperationException("SHIFT_CLOSED: Cannot post sales to a closed shift.");
        if (variant.OrgId != shift.OrgId)
            throw new UnauthorizedAccessException("BOLA Blocked: Variant does not belong to shift organization.");
        if (variant.RowVersion != expectedRowVersion)
            throw new InvalidOperationException("CONCURRENCY_CONFLICT: Variant stock modified by another cashier; reload and retry.");
        if (qty <= 0m || qty > variant.QtyOnHand)
            throw new InvalidOperationException($"OUT_OF_STOCK: Requested {qty} exceeds available {variant.QtyOnHand} for {variant.VariantSku}.");

        var total = R4(qty * variant.SalePrice);
        if (R4(cashPaid + cardPaid + creditAmount) != total)
            throw new InvalidOperationException("PAYMENT_SPLIT_MISMATCH: Cash + Card + Credit must equal sale total.");

        variant.QtyOnHand = R4(variant.QtyOnHand - qty);
        variant.RowVersion++;

        shift.TotalCashSales   = R4(shift.TotalCashSales + cashPaid);
        shift.TotalCardSales   = R4(shift.TotalCardSales + cardPaid);
        shift.TotalCreditSales = R4(shift.TotalCreditSales + creditAmount);
    }

    public void RecordCashRefund(PosShift shift, decimal refundCashAmount)
    {
        if (shift.Status != ShiftStatus.Open)
            throw new InvalidOperationException("SHIFT_CLOSED: Cannot post refund to a closed shift.");
        if (refundCashAmount <= 0m) throw new ArgumentOutOfRangeException(nameof(refundCashAmount));
        shift.TotalCashRefunds = R4(shift.TotalCashRefunds + refundCashAmount);
    }

    /// <summary>
    /// Blind Close Shift -> Computes Expected Cash & Variance -> Posts balanced Shortage/Overage journal -> Locks Z-Report with SHA-256.
    /// </summary>
    public (ZReportSummary Report, JournalEntry? VarianceEntry) CloseShiftAndGenerateZReport(
        PosShift shift, string zReportNumber, decimal physicalCountedCash,
        Guid terminalCashAccId, Guid cashShortageExpenseAccId, Guid cashOverageIncomeAccId)
    {
        if (shift.Status == ShiftStatus.Closed)
            throw new InvalidOperationException("Z_REPORT_IMMUTABILITY_VIOLATION: Shift is already closed.");
        if (physicalCountedCash < 0m) throw new ArgumentOutOfRangeException(nameof(physicalCountedCash));

        var expectedCash = R4(shift.OpeningFloat + shift.TotalCashSales - shift.TotalCashRefunds);
        var counted = R4(physicalCountedCash);
        var variance = R4(counted - expectedCash); // >0 overage, <0 shortage

        JournalEntry? varianceEntry = null;
        if (variance != 0m)
        {
            varianceEntry = new JournalEntry
            {
                OrgId = shift.OrgId,
                IdempotencyKey = $"ZREPORT-VAR-{shift.Id}",
                ReferenceType = "POS_SHIFT_VARIANCE",
                ReferenceId = shift.Id,
                Description = variance < 0m
                    ? $"Cashier Shift Shortage (عجز صندوق) - {zReportNumber}"
                    : $"Cashier Shift Overage (زيادة صندوق) - {zReportNumber}",
                Currency = shift.Currency
            };

            var absVar = Math.Abs(variance);
            if (variance < 0m)
            {
                // Shortage: Dr Cash Shortage Expense / Cr Terminal Cash Drawer
                varianceEntry.AddLine(new JournalLine { OrgId = shift.OrgId, AccountId = cashShortageExpenseAccId, Debit = absVar });
                varianceEntry.AddLine(new JournalLine { OrgId = shift.OrgId, AccountId = terminalCashAccId, Credit = absVar });
            }
            else
            {
                // Overage: Dr Terminal Cash Drawer / Cr Cash Overage Income
                varianceEntry.AddLine(new JournalLine { OrgId = shift.OrgId, AccountId = terminalCashAccId, Debit = absVar });
                varianceEntry.AddLine(new JournalLine { OrgId = shift.OrgId, AccountId = cashOverageIncomeAccId, Credit = absVar });
            }

            varianceEntry.EnsureBalanced();
            _varianceLedger.Add(varianceEntry);
        }

        shift.ExpectedCash = expectedCash;
        shift.CountedCash = counted;
        shift.CashVariance = variance;
        shift.ZReportNumber = zReportNumber;
        shift.VarianceJournalId = varianceEntry?.Id;
        shift.ClosedAt = DateTimeOffset.UtcNow;
        shift.Status = ShiftStatus.Closed;

        var canonicalPayload = JsonSerializer.Serialize(new
        {
            shift.Id,
            shift.OrgId,
            shift.TerminalId,
            shift.CashierUserId,
            shift.Currency,
            shift.OpeningFloat,
            shift.TotalCashSales,
            shift.TotalCardSales,
            shift.TotalCreditSales,
            shift.TotalCashRefunds,
            ExpectedCash = expectedCash,
            CountedCash = counted,
            CashVariance = variance,
            ZReportNumber = zReportNumber
        });
        shift.ZReportSha256 = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(canonicalPayload))).ToLowerInvariant();

        var summary = new ZReportSummary(
            zReportNumber, shift.Id, shift.TerminalId, shift.CashierUserId, shift.Currency,
            shift.OpeningFloat, shift.TotalCashSales, shift.TotalCardSales, shift.TotalCreditSales,
            shift.TotalCashRefunds, expectedCash, counted, variance, shift.ZReportSha256, varianceEntry?.Id);

        return (summary, varianceEntry);
    }

    public decimal VerifyVarianceLedgerBalance(Guid orgId)
    {
        var lines = _varianceLedger.Where(e => e.OrgId == orgId).SelectMany(e => e.Lines);
        return R4(lines.Sum(l => l.Debit) - lines.Sum(l => l.Credit));
    }
}
