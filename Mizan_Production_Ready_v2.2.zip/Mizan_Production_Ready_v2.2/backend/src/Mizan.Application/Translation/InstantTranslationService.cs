using System.Security.Cryptography;
using System.Text;

namespace Mizan.Application.Translation;

public sealed record TranslationResult(
    string OriginalText,
    string TranslatedText,
    string SourceLang,
    string TargetLang,
    bool FromCache,
    string Provider
);

/// <summary>Hexagonal port for plugging Google Translate, DeepL, Azure Translator, or LLM providers in Phase 2.</summary>
public interface ITranslationAdapter
{
    string ProviderName { get; }
    Task<string> TranslateAsync(string text, string sourceLang, string targetLang, CancellationToken ct = default);
}

/// <summary>Safe Phase-1 adapter bound when INSTANT_CROSS_BORDER_TRANSLATION is OFF.</summary>
public sealed class DisabledTranslationAdapter : ITranslationAdapter
{
    public string ProviderName => "DISABLED_PHASE1";
    public Task<string> TranslateAsync(string text, string sourceLang, string targetLang, CancellationToken ct = default)
        => throw new InvalidOperationException("FEATURE_DISABLED_BY_POLICY: INSTANT_CROSS_BORDER_TRANSLATION is inactive in Phase 1.");
}

/// <summary>
/// Deterministic SHA-256 cached translation service.
/// Strictly translates text fields ONLY (item names, notes, chat) — never mutates numeric totals, SKUs, or currency codes.
/// </summary>
public sealed class InstantTranslationService
{
    private readonly ITranslationAdapter _adapter;
    private readonly Func<Guid, string, bool> _isFeatureEnabled;
    private readonly Dictionary<(string Hash, string Src, string Tgt), string> _cache = new();

    public InstantTranslationService(ITranslationAdapter adapter, Func<Guid, string, bool> isFeatureEnabled)
    {
        _adapter = adapter;
        _isFeatureEnabled = isFeatureEnabled;
    }

    public async Task<TranslationResult> TranslateFieldAsync(
        Guid orgId, string text, string sourceLang, string targetLang, CancellationToken ct = default)
    {
        var src = sourceLang.Trim().ToLowerInvariant();
        var tgt = targetLang.Trim().ToLowerInvariant();

        if (string.IsNullOrWhiteSpace(text) || src == tgt)
            return new TranslationResult(text, text, src, tgt, FromCache: true, Provider: "PASSTHROUGH");

        if (!_isFeatureEnabled(orgId, "INSTANT_CROSS_BORDER_TRANSLATION"))
            throw new InvalidOperationException("FEATURE_DISABLED_BY_POLICY: INSTANT_CROSS_BORDER_TRANSLATION is disabled.");

        var hash = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(text))).ToLowerInvariant();
        if (_cache.TryGetValue((hash, src, tgt), out var cachedText))
            return new TranslationResult(text, cachedText, src, tgt, FromCache: true, Provider: _adapter.ProviderName);

        var translated = await _adapter.TranslateAsync(text, src, tgt, ct);
        _cache[(hash, src, tgt)] = translated;
        return new TranslationResult(text, translated, src, tgt, FromCache: false, Provider: _adapter.ProviderName);
    }
}
