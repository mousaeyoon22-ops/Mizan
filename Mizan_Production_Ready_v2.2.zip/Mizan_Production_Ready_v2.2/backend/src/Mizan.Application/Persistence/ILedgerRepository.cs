using Mizan.Domain.Entities;

namespace Mizan.Application.Persistence;

public interface ILedgerRepository
{
    Task<JournalEntry?> FindByIdempotencyKeyAsync(Guid orgId, string idempotencyKey, CancellationToken ct = default);
    Task SaveJournalEntryAsync(JournalEntry entry, CancellationToken ct = default);
    Task<decimal> GetTrialBalanceVarianceAsync(Guid orgId, CancellationToken ct = default);
    Task<decimal> GetAccountBalanceAsync(Guid orgId, Guid accountId, CancellationToken ct = default);
}

public interface IOrderChannelAccessValidator
{
    Task<(bool IsParty, bool IsChatLocked)> ValidateOrderChannelAccessAsync(Guid userId, Guid orgId, Guid orderId, CancellationToken ct = default);
}
