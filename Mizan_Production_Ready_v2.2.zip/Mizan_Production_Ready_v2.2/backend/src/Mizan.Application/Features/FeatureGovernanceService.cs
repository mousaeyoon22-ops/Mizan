using Mizan.Domain.Features;

namespace Mizan.Application.Features;

public sealed record EffectiveFeatureState(
    string Key,
    FeatureCategory Category,
    int ReleasePhase,
    bool IsImmutableCore,
    bool PlatformEnabled,
    bool OrgConfigurable,
    bool EffectiveEnabled,
    string? RequiresFeature
);

/// <summary>
/// Evaluates and enforces 3-tier feature governance:
/// EffectiveEnabled = PlatformEnabled && DependencySatisfied && (OrgPreference ?? DefaultOrgState)
/// </summary>
public sealed class FeatureGovernanceService
{
    private readonly Dictionary<string, FeatureDefinition> _platformRegistry;
    private readonly Dictionary<(Guid OrgId, string Key), bool> _orgOverrides = new();

    public FeatureGovernanceService(IEnumerable<FeatureDefinition> initialRegistry)
    {
        _platformRegistry = initialRegistry.ToDictionary(x => x.Key, StringComparer.Ordinal);
    }

    public bool IsEnabled(Guid orgId, string featureKey)
    {
        if (!_platformRegistry.TryGetValue(featureKey, out var def))
            return false;

        if (def.IsImmutableCore) return true;
        if (!def.PlatformEnabled) return false;

        if (def.RequiresFeature is not null && !IsEnabled(orgId, def.RequiresFeature))
            return false;

        if (_orgOverrides.TryGetValue((orgId, featureKey), out var orgState))
            return orgState;

        return def.DefaultOrgState;
    }

    public void SetOrganizationPreference(Guid orgId, string featureKey, bool desiredState)
    {
        if (!_platformRegistry.TryGetValue(featureKey, out var def))
            throw new KeyNotFoundException($"Unknown feature key: {featureKey}");

        if (def.IsImmutableCore && !desiredState)
            throw new InvalidOperationException($"CORE_FEATURE_IMMUTABLE: {featureKey} cannot be disabled.");

        if (desiredState && (!def.PlatformEnabled || !def.OrgConfigurable))
            throw new InvalidOperationException($"FEATURE_LOCKED_BY_PLATFORM: {featureKey} is locked for Phase {def.ReleasePhase}.");

        if (desiredState && def.RequiresFeature is not null && !IsEnabled(orgId, def.RequiresFeature))
            throw new InvalidOperationException($"FEATURE_DEPENDENCY_MISSING: {featureKey} requires {def.RequiresFeature}.");

        _orgOverrides[(orgId, featureKey)] = desiredState;
    }

    public void SetPlatformFlag(string featureKey, bool platformEnabled)
    {
        if (!_platformRegistry.TryGetValue(featureKey, out var def))
            throw new KeyNotFoundException($"Unknown feature key: {featureKey}");

        if (def.IsImmutableCore && !platformEnabled)
            throw new InvalidOperationException($"CORE_FEATURE_IMMUTABLE: {featureKey} cannot be disabled globally.");

        _platformRegistry[featureKey] = def with { PlatformEnabled = platformEnabled };
    }

    public IReadOnlyList<EffectiveFeatureState> GetEffectiveMatrix(Guid orgId)
    {
        return _platformRegistry.Values
            .OrderBy(x => x.ReleasePhase)
            .ThenBy(x => x.Key)
            .Select(def => new EffectiveFeatureState(
                def.Key,
                def.Category,
                def.ReleasePhase,
                def.IsImmutableCore,
                def.PlatformEnabled,
                def.OrgConfigurable,
                IsEnabled(orgId, def.Key),
                def.RequiresFeature))
            .ToList();
    }
}
