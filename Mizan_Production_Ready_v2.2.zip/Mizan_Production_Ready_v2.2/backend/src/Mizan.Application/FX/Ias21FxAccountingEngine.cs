using Mizan.Domain.FX;

namespace Mizan.Application.FX;

/// <summary>
/// IAS 21 Multi-Currency Accounting & Direct Currency Exchange (المصارفة) Engine.
/// Guarantees 0.0000 trial balance variance in functional (base) currency across:
/// 1) Foreign-currency AR/AP settlement with realized FX Gain/Loss
/// 2) Direct Currency Exchange Vouchers (converting cash/bank boxes with exchange spread posting)
/// 3) Period-end monetary balance revaluation (unrealized FX Gain/Loss)
/// </summary>
public sealed class Ias21FxAccountingEngine
{
    private readonly Dictionary<(Guid OrgId, string Key), FxCalculationSummary> _idempotencyStore = new();
    private readonly List<DualCurrencyJournalEntry> _ledger = new();

    public IReadOnlyList<DualCurrencyJournalEntry> Ledger => _ledger.AsReadOnly();

    private static decimal R4(decimal val) => Math.Round(val, 4, MidpointRounding.AwayFromZero);

    /// <summary>
    /// Settles a foreign-currency Accounts Receivable (AR) balance at a new spot rate.
    /// Closes AR at historical booking rate and posts exact difference to FX Gain or FX Loss.
    /// </summary>
    public FxCalculationSummary SettleForeignReceivable(
        Guid orgId, string idempotencyKey, Guid settlementDocId,
        string baseCurrency, string txCurrency, decimal txAmount,
        decimal historicalRateToBase, decimal settlementRateToBase,
        Guid cashAccId, Guid arAccId, Guid fxGainAccId, Guid fxLossAccId, Guid? customerOrgId)
    {
        if (_idempotencyStore.TryGetValue((orgId, idempotencyKey), out var cached))
            return cached;

        var arBaseAmount = R4(txAmount * historicalRateToBase);
        var cashBaseAmount = R4(txAmount * settlementRateToBase);
        var fxDiff = R4(cashBaseAmount - arBaseAmount); // Positive = Gain, Negative = Loss

        var entry = new DualCurrencyJournalEntry
        {
            OrgId = orgId,
            IdempotencyKey = idempotencyKey,
            ReferenceType = "FX_AR_SETTLEMENT",
            ReferenceId = settlementDocId,
            BaseCurrency = baseCurrency,
            Description = $"IAS 21 AR Settlement: {txAmount} {txCurrency} (Hist={historicalRateToBase}, Sett={settlementRateToBase})"
        };

        entry.AddLine(new DualCurrencyJournalLine
        {
            OrgId = orgId, AccountId = cashAccId, TransactionCurrency = txCurrency,
            ExchangeRateToBase = settlementRateToBase, TxDebit = R4(txAmount), BaseDebit = cashBaseAmount
        });

        entry.AddLine(new DualCurrencyJournalLine
        {
            OrgId = orgId, AccountId = arAccId, PartyOrgId = customerOrgId, TransactionCurrency = txCurrency,
            ExchangeRateToBase = historicalRateToBase, TxCredit = R4(txAmount), BaseCredit = arBaseAmount
        });

        AppendFxDiffLine(entry, orgId, baseCurrency, fxDiff, fxGainAccId, fxLossAccId);
        return Commit(entry, fxDiff, baseCurrency);
    }

    /// <summary>
    /// Settles a foreign-currency Accounts Payable (AP) balance at a new spot rate.
    /// If settlementRate > historicalRate -> FX Loss; if settlementRate < historicalRate -> FX Gain.
    /// </summary>
    public FxCalculationSummary SettleForeignPayable(
        Guid orgId, string idempotencyKey, Guid settlementDocId,
        string baseCurrency, string txCurrency, decimal txAmount,
        decimal historicalRateToBase, decimal settlementRateToBase,
        Guid apAccId, Guid cashAccId, Guid fxGainAccId, Guid fxLossAccId, Guid? supplierOrgId)
    {
        if (_idempotencyStore.TryGetValue((orgId, idempotencyKey), out var cached))
            return cached;

        var apBaseAmount = R4(txAmount * historicalRateToBase);
        var cashBaseAmount = R4(txAmount * settlementRateToBase);
        var fxDiff = R4(apBaseAmount - cashBaseAmount); // Positive = Gain (paid less), Negative = Loss (paid more)

        var entry = new DualCurrencyJournalEntry
        {
            OrgId = orgId,
            IdempotencyKey = idempotencyKey,
            ReferenceType = "FX_AP_SETTLEMENT",
            ReferenceId = settlementDocId,
            BaseCurrency = baseCurrency,
            Description = $"IAS 21 AP Settlement: {txAmount} {txCurrency} (Hist={historicalRateToBase}, Sett={settlementRateToBase})"
        };

        entry.AddLine(new DualCurrencyJournalLine
        {
            OrgId = orgId, AccountId = apAccId, PartyOrgId = supplierOrgId, TransactionCurrency = txCurrency,
            ExchangeRateToBase = historicalRateToBase, TxDebit = R4(txAmount), BaseDebit = apBaseAmount
        });

        entry.AddLine(new DualCurrencyJournalLine
        {
            OrgId = orgId, AccountId = cashAccId, TransactionCurrency = txCurrency,
            ExchangeRateToBase = settlementRateToBase, TxCredit = R4(txAmount), BaseCredit = cashBaseAmount
        });

        AppendFxDiffLine(entry, orgId, baseCurrency, fxDiff, fxGainAccId, fxLossAccId);
        return Commit(entry, fxDiff, baseCurrency);
    }

    /// <summary>
    /// Direct Currency Exchange Voucher (سند المصارفة المباشر):
    /// Converts sourceAmount in sourceCurrency into targetAmount in targetCurrency.
    /// Computes base-currency spread (targetBase - sourceBase) and automatically posts it as
    /// FX Exchange Gain (إيراد مصارفة) or FX Exchange Loss/Expense (مصروف/فرق مصارفة).
    /// </summary>
    public FxCalculationSummary ExecuteDirectCurrencyExchange(
        Guid orgId, string idempotencyKey, Guid voucherId, string baseCurrency,
        Guid sourceCashAccId, string sourceCurrency, decimal sourceAmount, decimal sourceBookRateToBase,
        Guid targetCashAccId, string targetCurrency, decimal targetAmount, decimal targetBookRateToBase,
        Guid fxExchangeGainAccId, Guid fxExchangeLossAccId)
    {
        if (_idempotencyStore.TryGetValue((orgId, idempotencyKey), out var cached))
            return cached;

        if (string.Equals(sourceCurrency, targetCurrency, StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException("Source and target currencies must differ for a currency exchange voucher.");

        var sourceBase = R4(sourceAmount * sourceBookRateToBase);
        var targetBase = R4(targetAmount * targetBookRateToBase);
        var fxSpread = R4(targetBase - sourceBase); // > 0 Gain, < 0 Loss (Exchange Spread Expense)

        var entry = new DualCurrencyJournalEntry
        {
            OrgId = orgId,
            IdempotencyKey = idempotencyKey,
            ReferenceType = "FX_EXCHANGE_VOUCHER",
            ReferenceId = voucherId,
            BaseCurrency = baseCurrency,
            Description = $"Direct Exchange (مصارفة): {sourceAmount} {sourceCurrency} -> {targetAmount} {targetCurrency}"
        };

        entry.AddLine(new DualCurrencyJournalLine
        {
            OrgId = orgId, AccountId = targetCashAccId, TransactionCurrency = targetCurrency,
            ExchangeRateToBase = targetBookRateToBase, TxDebit = R4(targetAmount), BaseDebit = targetBase
        });

        entry.AddLine(new DualCurrencyJournalLine
        {
            OrgId = orgId, AccountId = sourceCashAccId, TransactionCurrency = sourceCurrency,
            ExchangeRateToBase = sourceBookRateToBase, TxCredit = R4(sourceAmount), BaseCredit = sourceBase
        });

        AppendFxDiffLine(entry, orgId, baseCurrency, fxSpread, fxExchangeGainAccId, fxExchangeLossAccId);
        return Commit(entry, fxSpread, baseCurrency);
    }

    /// <summary>IAS 21 Period-End Revaluation for open monetary assets (Cash/AR).</summary>
    public FxCalculationSummary RevalueMonetaryAsset(
        Guid orgId, string idempotencyKey, Guid revalId, string baseCurrency,
        Guid monetaryAccId, string foreignCurrency, decimal openForeignBalance,
        decimal currentBookRateToBase, decimal closingRateToBase,
        Guid unrealizedGainAccId, Guid unrealizedLossAccId)
    {
        if (_idempotencyStore.TryGetValue((orgId, idempotencyKey), out var cached))
            return cached;

        var oldBase = R4(openForeignBalance * currentBookRateToBase);
        var newBase = R4(openForeignBalance * closingRateToBase);
        var diff = R4(newBase - oldBase);

        var entry = new DualCurrencyJournalEntry
        {
            OrgId = orgId,
            IdempotencyKey = idempotencyKey,
            ReferenceType = "IAS21_REVALUATION",
            ReferenceId = revalId,
            BaseCurrency = baseCurrency,
            Description = $"IAS 21 Period-End Revaluation: {openForeignBalance} {foreignCurrency} ({currentBookRateToBase} -> {closingRateToBase})"
        };

        if (diff > 0m)
        {
            entry.AddLine(new DualCurrencyJournalLine { OrgId = orgId, AccountId = monetaryAccId, TransactionCurrency = baseCurrency, ExchangeRateToBase = 1m, TxDebit = diff, BaseDebit = diff });
            entry.AddLine(new DualCurrencyJournalLine { OrgId = orgId, AccountId = unrealizedGainAccId, TransactionCurrency = baseCurrency, ExchangeRateToBase = 1m, TxCredit = diff, BaseCredit = diff });
        }
        else if (diff < 0m)
        {
            var absDiff = Math.Abs(diff);
            entry.AddLine(new DualCurrencyJournalLine { OrgId = orgId, AccountId = unrealizedLossAccId, TransactionCurrency = baseCurrency, ExchangeRateToBase = 1m, TxDebit = absDiff, BaseDebit = absDiff });
            entry.AddLine(new DualCurrencyJournalLine { OrgId = orgId, AccountId = monetaryAccId, TransactionCurrency = baseCurrency, ExchangeRateToBase = 1m, TxCredit = absDiff, BaseCredit = absDiff });
        }
        else
        {
            return new FxCalculationSummary(entry, 0m, baseCurrency);
        }

        return Commit(entry, diff, baseCurrency);
    }

    public decimal VerifyBaseTrialBalanceVariance(Guid orgId)
    {
        var lines = _ledger.Where(e => e.OrgId == orgId).SelectMany(e => e.Lines);
        return R4(lines.Sum(l => l.BaseDebit) - lines.Sum(l => l.BaseCredit));
    }

    private static void AppendFxDiffLine(
        DualCurrencyJournalEntry entry, Guid orgId, string baseCurrency,
        decimal fxDiff, Guid fxGainAccId, Guid fxLossAccId)
    {
        if (fxDiff > 0m)
        {
            entry.AddLine(new DualCurrencyJournalLine
            {
                OrgId = orgId, AccountId = fxGainAccId, TransactionCurrency = baseCurrency,
                ExchangeRateToBase = 1m, TxCredit = fxDiff, BaseCredit = fxDiff
            });
        }
        else if (fxDiff < 0m)
        {
            var loss = Math.Abs(fxDiff);
            entry.AddLine(new DualCurrencyJournalLine
            {
                OrgId = orgId, AccountId = fxLossAccId, TransactionCurrency = baseCurrency,
                ExchangeRateToBase = 1m, TxDebit = loss, BaseDebit = loss
            });
        }
    }

    private FxCalculationSummary Commit(DualCurrencyJournalEntry entry, decimal fxDiff, string baseCurrency)
    {
        entry.EnsureBaseCurrencyBalanced();
        _ledger.Add(entry);
        var summary = new FxCalculationSummary(entry, fxDiff, baseCurrency);
        _idempotencyStore[(entry.OrgId, entry.IdempotencyKey)] = summary;
        return summary;
    }
}
