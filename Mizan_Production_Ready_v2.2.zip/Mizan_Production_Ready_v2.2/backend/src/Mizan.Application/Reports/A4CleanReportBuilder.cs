using System.Text;

namespace Mizan.Application.Reports;

public sealed record DailySalesRow(string? CustomerName, string? ItemLabel, decimal Qty, decimal UnitPrice, decimal Total, string? PaymentType);
public sealed record DailyExpenseRow(string? Category, string? Description, decimal Amount);
public sealed record MeterReadingRow(string? MeterName, decimal OpeningReading, decimal ClosingReading);
public sealed record CustomerBalanceRow(string? CustomerName, decimal PreviousBalance, decimal TodayDebit, decimal TodayCredit);

public sealed record CleanA4DailyReportModel(
    string OrgName,
    DateOnly ReportDate,
    string Currency,
    IReadOnlyList<DailySalesRow> SalesRows,
    IReadOnlyList<DailyExpenseRow> ExpenseRows,
    IReadOnlyList<MeterReadingRow> MeterReadings,
    IReadOnlyList<CustomerBalanceRow> CustomerBalances,
    decimal TotalSales,
    decimal TotalExpenses,
    decimal NetCashFlow,
    decimal TrialBalanceVariance
);

/// <summary>
/// Builds clean A4-formatted printable daily financial reports that strictly strip empty rows,
/// zero-value filler entries, and placeholder labels (e.g., "TBD", "N/A", "---").
/// </summary>
public sealed class A4CleanReportBuilder
{
    private static readonly HashSet<string> PlaceholderTokens = new(StringComparer.OrdinalIgnoreCase)
    {
        "", "-", "--", "---", "n/a", "tbd", "placeholder", "فارغ", "اختياري"
    };

    private static bool IsMeaningfulLabel(string? text)
        => !string.IsNullOrWhiteSpace(text) && !PlaceholderTokens.Contains(text.Trim());

    public CleanA4DailyReportModel BuildCleanModel(
        string orgName,
        DateOnly reportDate,
        string currency,
        IEnumerable<DailySalesRow> rawSales,
        IEnumerable<DailyExpenseRow> rawExpenses,
        IEnumerable<MeterReadingRow> rawMeters,
        IEnumerable<CustomerBalanceRow> rawBalances,
        decimal trialBalanceVariance,
        bool hideEmptyRows = true)
    {
        var sales = hideEmptyRows
            ? rawSales.Where(r => r.Qty > 0m && r.Total > 0m && (IsMeaningfulLabel(r.CustomerName) || IsMeaningfulLabel(r.ItemLabel))).ToList()
            : rawSales.ToList();

        var expenses = hideEmptyRows
            ? rawExpenses.Where(e => e.Amount > 0m && (IsMeaningfulLabel(e.Category) || IsMeaningfulLabel(e.Description))).ToList()
            : rawExpenses.ToList();

        var meters = hideEmptyRows
            ? rawMeters.Where(m => IsMeaningfulLabel(m.MeterName) && (m.ClosingReading > 0m || m.OpeningReading > 0m)).ToList()
            : rawMeters.ToList();

        var balances = hideEmptyRows
            ? rawBalances.Where(b => IsMeaningfulLabel(b.CustomerName) && (b.PreviousBalance != 0m || b.TodayDebit != 0m || b.TodayCredit != 0m)).ToList()
            : rawBalances.ToList();

        var totalSales = Math.Round(sales.Sum(s => s.Total), 4, MidpointRounding.AwayFromZero);
        var totalExpenses = Math.Round(expenses.Sum(e => e.Amount), 4, MidpointRounding.AwayFromZero);
        var netFlow = Math.Round(totalSales - totalExpenses, 4, MidpointRounding.AwayFromZero);

        return new CleanA4DailyReportModel(
            orgName, reportDate, currency.ToUpperInvariant(),
            sales, expenses, meters, balances,
            totalSales, totalExpenses, netFlow,
            Math.Round(trialBalanceVariance, 4, MidpointRounding.AwayFromZero));
    }

    public string RenderA4Html(CleanA4DailyReportModel model, bool isArabic = true)
    {
        var dir = isArabic ? "rtl" : "ltr";
        var sb = new StringBuilder();
        sb.AppendLine($"<!DOCTYPE html><html lang="{(isArabic ? "ar" : "en")}" dir="{dir}"><head><meta charset="utf-8">");
        sb.AppendLine("<style>@page{size:A4;margin:14mm;}body{font-family:Arial,sans-serif;color:#111;font-size:12px;}table{width:100%;border-collapse:collapse;margin-bottom:12px;}th,td{border:1px solid #cbd5e1;padding:6px;text-align:start;}th{background:#f1f5f9;}h1{font-size:18px;margin:0 0 4px;}h2{font-size:14px;margin:12px 0 6px;border-bottom:1px solid #0f766e;}</style></head><body>");
        sb.AppendLine($"<h1>{System.Net.WebUtility.HtmlEncode(model.OrgName)}</h1>");
        sb.AppendLine($"<div>{(isArabic ? "التقرير المالي اليومي" : "Daily Financial Report")}: {model.ReportDate:yyyy-MM-dd} | {model.Currency} | Variance: {model.TrialBalanceVariance:0.0000}</div>");

        if (model.SalesRows.Count > 0)
        {
            sb.AppendLine($"<h2>{(isArabic ? "حركات المبيعات المدخلة" : "Itemized Sales")}</h2><table><thead><tr><th>{(isArabic ? "العميل" : "Customer")}</th><th>{(isArabic ? "الصنف" : "Item")}</th><th>{(isArabic ? "الكمية" : "Qty")}</th><th>{(isArabic ? "الإجمالي" : "Total")}</th></tr></thead><tbody>");
            foreach (var s in model.SalesRows)
                sb.AppendLine($"<tr><td>{System.Net.WebUtility.HtmlEncode(s.CustomerName ?? "")}</td><td>{System.Net.WebUtility.HtmlEncode(s.ItemLabel ?? "")}</td><td>{s.Qty:0.##}</td><td>{s.Total:0.00} {model.Currency}</td></tr>");
            sb.AppendLine("</tbody></table>");
        }

        if (model.MeterReadings.Count > 0)
        {
            sb.AppendLine($"<h2>{(isArabic ? "قراءات العدادات" : "Meter Readings")}</h2><table><thead><tr><th>{(isArabic ? "العداد" : "Meter")}</th><th>{(isArabic ? "السابق" : "Opening")}</th><th>{(isArabic ? "الحالي" : "Closing")}</th><th>{(isArabic ? "الفرق" : "Delta")}</th></tr></thead><tbody>");
            foreach (var m in model.MeterReadings)
                sb.AppendLine($"<tr><td>{System.Net.WebUtility.HtmlEncode(m.MeterName ?? "")}</td><td>{m.OpeningReading:0.##}</td><td>{m.ClosingReading:0.##}</td><td>{(m.ClosingReading - m.OpeningReading):0.##}</td></tr>");
            sb.AppendLine("</tbody></table>");
        }

        if (model.ExpenseRows.Count > 0)
        {
            sb.AppendLine($"<h2>{(isArabic ? "المصروفات" : "Expenses")}</h2><table><thead><tr><th>{(isArabic ? "البند" : "Category")}</th><th>{(isArabic ? "البيان" : "Description")}</th><th>{(isArabic ? "المبلغ" : "Amount")}</th></tr></thead><tbody>");
            foreach (var e in model.ExpenseRows)
                sb.AppendLine($"<tr><td>{System.Net.WebUtility.HtmlEncode(e.Category ?? "")}</td><td>{System.Net.WebUtility.HtmlEncode(e.Description ?? "")}</td><td>{e.Amount:0.00} {model.Currency}</td></tr>");
            sb.AppendLine("</tbody></table>");
        }

        if (model.CustomerBalances.Count > 0)
        {
            sb.AppendLine($"<h2>{(isArabic ? "الأرصدة التراكمية للعملاء" : "Cumulative Customer Balances")}</h2><table><thead><tr><th>{(isArabic ? "العميل" : "Customer")}</th><th>{(isArabic ? "رصيد سابق" : "Previous")}</th><th>{(isArabic ? "مدين اليوم" : "Debit")}</th><th>{(isArabic ? "دائن اليوم" : "Credit")}</th><th>{(isArabic ? "الرصيد الختامي" : "Closing")}</th></tr></thead><tbody>");
            foreach (var b in model.CustomerBalances)
            {
                var closing = b.PreviousBalance + b.TodayDebit - b.TodayCredit;
                sb.AppendLine($"<tr><td>{System.Net.WebUtility.HtmlEncode(b.CustomerName ?? "")}</td><td>{b.PreviousBalance:0.00}</td><td>{b.TodayDebit:0.00}</td><td>{b.TodayCredit:0.00}</td><td>{closing:0.00} {model.Currency}</td></tr>");
            }
            sb.AppendLine("</tbody></table>");
        }

        sb.AppendLine($"<div><strong>{(isArabic ? "إجمالي المبيعات" : "Total Sales")}:</strong> {model.TotalSales:0.00} {model.Currency} | <strong>{(isArabic ? "إجمالي المصروفات" : "Total Expenses")}:</strong> {model.TotalExpenses:0.00} {model.Currency} | <strong>{(isArabic ? "الصافي" : "Net")}:</strong> {model.NetCashFlow:0.00} {model.Currency}</div>");
        sb.AppendLine("</body></html>");
        return sb.ToString();
    }
}
