namespace Mizan.Application.Adapters;

/// <summary>
/// Clean hexagonal ports embedded in v1.0.
/// In Phase 1, safe Disabled/Stub adapters are bound via DI; in Phase 2/3, live Stripe/ERP/Tax/AI
/// implementations swap in via configuration with zero changes to core ledger logic.
/// </summary>
public interface IPaymentGatewayAdapter
{
    Task<string> AuthorizeHoldAsync(Guid orderId, decimal amount, string currency, CancellationToken ct = default);
    Task CaptureHoldAsync(string authRef, decimal amount, CancellationToken ct = default);
    Task VoidHoldAsync(string authRef, CancellationToken ct = default);
}

public interface IErpConnectorAdapter
{
    string ProviderName { get; } // QuickBooks | Xero | Zoho | Odoo | SAP
    Task PushUblDocumentAsync(Guid orgId, string ublJson, CancellationToken ct = default);
}

public interface ITaxAuthorityAdapter
{
    string JurisdictionCode { get; } // SA-ZATCA | AE-FTA | EU-PEPPOL
    Task<string> SubmitEInvoiceAsync(string ublXmlOrJson, CancellationToken ct = default);
}

public interface IAiCopilotAdapter
{
    Task<string> ExtractInvoiceOcrJsonAsync(byte[] imageBytes, CancellationToken ct = default);
}

public sealed class DisabledPaymentGatewayAdapter : IPaymentGatewayAdapter
{
    public Task<string> AuthorizeHoldAsync(Guid orderId, decimal amount, string currency, CancellationToken ct = default)
        => throw new InvalidOperationException("FEATURE_DISABLED_BY_POLICY: PSP_PASS_THROUGH_PREAUTH is disabled in Phase 1.");
    public Task CaptureHoldAsync(string authRef, decimal amount, CancellationToken ct = default)
        => throw new InvalidOperationException("FEATURE_DISABLED_BY_POLICY: PSP_PASS_THROUGH_PREAUTH is disabled in Phase 1.");
    public Task VoidHoldAsync(string authRef, CancellationToken ct = default)
        => throw new InvalidOperationException("FEATURE_DISABLED_BY_POLICY: PSP_PASS_THROUGH_PREAUTH is disabled in Phase 1.");
}
