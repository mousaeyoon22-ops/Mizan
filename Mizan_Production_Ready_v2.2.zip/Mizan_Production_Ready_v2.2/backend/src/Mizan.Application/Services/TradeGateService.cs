using System.Security.Cryptography;
using System.Text;
using Mizan.Domain.Entities;
using Mizan.Domain.StateMachines;

namespace Mizan.Application.Services;

/// <summary>
/// Enforces the 3 Separate Decisions:
/// 1) Pairing (Who can connect)
/// 2) Gate Approval (Which document types & direction are permitted)
/// 3) Independent Accounting Posting (Each org posts strictly inside its own ledger)
/// </summary>
public sealed class TradeGateService
{
    public GateDocument SendDocument(Pairing pairing, TradeGate gate, Guid actingOrgId, string idempotencyKey, string docType, string ublPayloadJson)
    {
        if (pairing.Status != PairingStatus.Active)
            throw new InvalidOperationException("Decision 1 Blocked: Pairing is not ACTIVE.");

        if (gate.Status != GateStatus.Active)
            throw new InvalidOperationException("Decision 2 Blocked: Trade Gate has not been approved by both organizations.");

        if (gate.SenderOrgId != actingOrgId)
            throw new UnauthorizedAccessException("BOLA Blocked: Only the authorized gate sender organization may dispatch documents.");

        var hash = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(ublPayloadJson))).ToLowerInvariant();
        var doc = new GateDocument
        {
            GateId = gate.Id,
            IdempotencyKey = idempotencyKey,
            DocType = docType,
            UblPayloadJson = ublPayloadJson,
            PayloadSha256 = hash,
            State = GateDocState.Draft
        };

        GateDocumentStateMachine.Transition(doc, GateDocState.Sent);
        return doc;
    }

    public void ApproveDocument(TradeGate gate, GateDocument doc, Guid actingOrgId)
    {
        if (gate.ReceiverOrgId != actingOrgId)
            throw new UnauthorizedAccessException("BOLA Blocked: Only the gate receiver organization may approve incoming documents.");

        GateDocumentStateMachine.Transition(doc, GateDocState.Approved);
    }

    public void MarkPostedByOrganization(TradeGate gate, GateDocument doc, Guid actingOrgId, Guid journalEntryId)
    {
        if (doc.State != GateDocState.Approved && doc.State != GateDocState.Posted)
            throw new InvalidOperationException("Decision 3 Blocked: Document must be approved before accounting posting.");

        if (actingOrgId == gate.SenderOrgId) doc.SenderJournalId = journalEntryId;
        else if (actingOrgId == gate.ReceiverOrgId) doc.ReceiverJournalId = journalEntryId;
        else throw new UnauthorizedAccessException("BOLA Blocked: Organization is not a party to this gate.");

        if (doc.SenderJournalId.HasValue && doc.ReceiverJournalId.HasValue && doc.State == GateDocState.Approved)
            GateDocumentStateMachine.Transition(doc, GateDocState.Posted);
    }
}
