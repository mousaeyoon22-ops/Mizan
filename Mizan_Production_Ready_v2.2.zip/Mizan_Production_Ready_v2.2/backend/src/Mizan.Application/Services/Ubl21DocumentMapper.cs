using System.Text.Json;

namespace Mizan.Application.Services;

/// <summary>Maps Mizan invoices to ISO/IEC 19845 (UBL 2.1) compatible JSON/Peppol structure.</summary>
public static class Ubl21DocumentMapper
{
    public static string SerializeUbl21Invoice(
        string invoiceId, DateTimeOffset issueDate, string currency,
        string supplierUid, string customerUid, decimal netAmount, decimal taxAmount)
    {
        var payload = new
        {
            UBLVersionID = "2.1",
            CustomizationID = "urn:cen.eu:en16931:2017#compliant#urn:mizan:global:1.0",
            ID = invoiceId,
            IssueDate = issueDate.ToString("yyyy-MM-dd"),
            DocumentCurrencyCode = currency,
            AccountingSupplierParty = new { PartyIdentification = supplierUid },
            AccountingCustomerParty = new { PartyIdentification = customerUid },
            LegalMonetaryTotal = new
            {
                TaxExclusiveAmount = Math.Round(netAmount, 4),
                TaxInclusiveAmount = Math.Round(netAmount + taxAmount, 4),
                PayableAmount = Math.Round(netAmount + taxAmount, 4)
            }
        };
        return JsonSerializer.Serialize(payload);
    }
}
