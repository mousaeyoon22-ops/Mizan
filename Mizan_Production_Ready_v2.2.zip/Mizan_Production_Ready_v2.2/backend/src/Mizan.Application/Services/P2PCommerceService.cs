using Mizan.Domain.Entities;
using Mizan.Domain.StateMachines;

namespace Mizan.Application.Services;

/// <summary>
/// Manages QR Live Cart -> P2P Authorize & Capture (Pass-through PSP, zero custody) -> Inspection -> Release/Void -> Double-Blind Rating.
/// </summary>
public sealed class P2PCommerceService
{
    public void AuthorizeOrder(P2POrder order, string? externalPspAuthRef, bool hasApprovedCreditLimit = false)
    {
        if (order.PaymentMode == PaymentMode.GatewayPreAuth && string.IsNullOrWhiteSpace(externalPspAuthRef))
            throw new InvalidOperationException("Pass-through Pre-Authorization reference from licensed PSP is required.");

        if ((order.PaymentMode == PaymentMode.Credit || order.PaymentMode == PaymentMode.PartialCredit) && !hasApprovedCreditLimit)
            throw new InvalidOperationException("Credit mode requires pre-approved credit limit or explicit seller approval.");

        order.GatewayAuthRef = externalPspAuthRef;
        order.PaymentStatus = order.PaymentMode == PaymentMode.GatewayPreAuth ? PaymentStatus.PreAuthorized : PaymentStatus.Unpaid;
        order.HoldExpiresAt = DateTimeOffset.UtcNow.AddMinutes(30);
        P2POrderStateMachine.Transition(order, P2POrderState.Submitted);
    }

    public void ConfirmInspectionAndRelease(P2POrder order, Guid actingBuyerUserId)
    {
        if (order.BuyerUserId != actingBuyerUserId)
            throw new UnauthorizedAccessException("BOLA Blocked: Only the order buyer may confirm receipt and release funds.");

        P2POrderStateMachine.Transition(order, P2POrderState.Completed);
        order.DeliveryStatus = DeliveryStatus.Delivered;
        order.DeliveredAt = DateTimeOffset.UtcNow;

        if (order.PaymentMode == PaymentMode.GatewayPreAuth)
        {
            order.PaymentStatus = PaymentStatus.Captured;
            order.PaidAmount = order.TotalAmount;
        }
    }

    public bool CanOpenDispute(P2POrder order, InventoryItem item, DateTimeOffset nowUtc, bool isLiveInAppCapture)
    {
        if (!isLiveInAppCapture) return false; // Anti-Fraud: Block gallery uploads
        if (order.DeliveredAt is null) return false;
        return (nowUtc - order.DeliveredAt.Value).TotalMinutes <= item.DisputeWindowMinutes;
    }

    public void RevealBlindRatingsIfEligible(List<BlindRating> orderRatings, DateTimeOffset nowUtc)
    {
        bool bothSubmitted = orderRatings.Any(r => r.RaterRole == "BUYER") && orderRatings.Any(r => r.RaterRole == "SELLER");
        foreach (var rating in orderRatings)
        {
            if (bothSubmitted || nowUtc >= rating.RevealAfter)
                rating.IsPublished = true;
        }
    }
}
