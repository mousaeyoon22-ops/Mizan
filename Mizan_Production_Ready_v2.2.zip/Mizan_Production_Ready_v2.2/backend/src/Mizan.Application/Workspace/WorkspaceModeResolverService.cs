using Mizan.Domain.Workspace;

namespace Mizan.Application.Workspace;

/// <summary>
/// Resolves the exact workspace layout AND data visibility matrix using strict set intersection:
/// EffectiveProfile = RequestedMode ∩ OrgRolePolicy ∩ RBAC_RoleCeiling ∩ ActiveFeatures ∩ AccessibilityGuard.
/// Security Invariant: Switching to PROFESSIONAL or EXECUTIVE mode NEVER bypasses RBAC role boundaries.
/// </summary>
public sealed class WorkspaceModeResolverService
{
    // Maximum allowed modes per RBAC Role (Security Ceiling)
    private static readonly Dictionary<string, WorkspaceExperienceMode[]> RoleModeCeiling = new(StringComparer.OrdinalIgnoreCase)
    {
        ["OWNER"]      = new[] { WorkspaceExperienceMode.Easy, WorkspaceExperienceMode.Standard, WorkspaceExperienceMode.Professional, WorkspaceExperienceMode.Executive, WorkspaceExperienceMode.ExpressField },
        ["ACCOUNTANT"] = new[] { WorkspaceExperienceMode.Easy, WorkspaceExperienceMode.Standard, WorkspaceExperienceMode.Professional, WorkspaceExperienceMode.Executive },
        ["AUDITOR"]    = new[] { WorkspaceExperienceMode.Standard, WorkspaceExperienceMode.Professional, WorkspaceExperienceMode.Executive },
        ["CASHIER"]    = new[] { WorkspaceExperienceMode.Easy, WorkspaceExperienceMode.Standard, WorkspaceExperienceMode.ExpressField },
        ["DRIVER"]     = new[] { WorkspaceExperienceMode.Easy, WorkspaceExperienceMode.ExpressField }
    };

    private static readonly HashSet<string> SensitiveFinancialFields = new(StringComparer.OrdinalIgnoreCase)
    {
        "gross_profit", "net_profit", "coa_code", "journal_debit_credit", "fifo_cost_layers",
        "weighted_avg_cost", "fx_gain_loss_spread", "trial_balance_variance", "audit_sha256_hash",
        "branch_consolidated_pnl", "all_cashiers_z_reports"
    };

    public ResolvedWorkspaceProfile Resolve(
        string userRole,
        WorkspaceExperienceMode requestedMode,
        OrgRoleModePolicy? orgPolicy = null,
        bool motorLargeTargets = false,
        bool cognitiveSimplified = false,
        bool hideEmptyPrintRows = true)
    {
        var role = string.IsNullOrWhiteSpace(userRole) ? "CASHIER" : userRole.ToUpperInvariant();
        var allowedByRole = RoleModeCeiling.TryGetValue(role, out var list)
            ? list
            : new[] { WorkspaceExperienceMode.Easy };

        var effectiveMode = requestedMode;
        bool clamped = false;
        string? clampReason = null;

        // 1) Enforce Organization Role Policy Lock first
        if (orgPolicy is not null && !orgPolicy.AllowUserOverride && requestedMode != orgPolicy.DefaultMode)
        {
            effectiveMode = orgPolicy.DefaultMode;
            clamped = true;
            clampReason = $"ORG_POLICY_LOCKED_ROLE_{role}_TO_{orgPolicy.DefaultMode}";
        }
        else if (orgPolicy is not null && !orgPolicy.AllowedModes.Contains(effectiveMode))
        {
            effectiveMode = orgPolicy.DefaultMode;
            clamped = true;
            clampReason = $"MODE_NOT_IN_ORG_POLICY_FOR_{role}";
        }

        // 2) Enforce Hard RBAC Ceiling (Experience Mode can NEVER escalate privileges)
        if (!allowedByRole.Contains(effectiveMode))
        {
            effectiveMode = allowedByRole.Contains(WorkspaceExperienceMode.Standard)
                ? WorkspaceExperienceMode.Standard
                : allowedByRole[0];
            clamped = true;
            clampReason = $"RBAC_CEILING_BLOCKED_{requestedMode}_FOR_{role}";
        }

        // 3) Compute Mode Layout, Terminology & Data Visibility Matrix
        var (terminology, density, maxNav, widgets, columns) = BuildModeSpec(effectiveMode);

        // 4) Intersect Data Fields with Role Security (Strip financial/profit fields from CASHIER & DRIVER)
        var hiddenFields = new List<string>();
        if (role is "CASHIER" or "DRIVER")
        {
            foreach (var sensitive in SensitiveFinancialFields)
            {
                if (widgets.Remove(sensitive) || columns.Remove(sensitive))
                    hiddenFields.Add(sensitive);
            }
        }

        // 5) Preserve WCAG Accessibility Overrides (from v1.6)
        if (cognitiveSimplified && density == UiDensity.Compact)
            density = UiDensity.Spacious;

        var minTouchDp = motorLargeTargets ? 64 : (density == UiDensity.Spacious ? 56 : 48);

        return new ResolvedWorkspaceProfile(
            EffectiveMode: effectiveMode,
            WasClampedByRoleOrPolicy: clamped,
            ClampReason: clampReason,
            Terminology: terminology,
            Density: density,
            MinTouchTargetDp: minTouchDp,
            MaxBottomNavItems: maxNav,
            HideEmptyPrintRows: hideEmptyPrintRows,
            VisibleWidgets: widgets,
            VisibleTableColumns: columns,
            HiddenSensitiveFields: hiddenFields
        );
    }

    private static (TerminologyStyle, UiDensity, int, List<string>, List<string>) BuildModeSpec(WorkspaceExperienceMode mode)
    {
        return mode switch
        {
            WorkspaceExperienceMode.Easy => (
                TerminologyStyle.SimpleTrade,
                UiDensity.Spacious,
                3,
                new List<string> { "today_cash_simple", "owed_to_me_simple", "owed_by_me_simple", "big_3_action_buttons" },
                new List<string> { "date", "party_name", "simple_direction_label", "amount_currency" }
            ),
            WorkspaceExperienceMode.Standard => (
                TerminologyStyle.Balanced,
                UiDensity.Comfortable,
                5,
                new List<string> { "cash_and_bank_boxes", "ar_ap_summary", "inventory_low_alerts", "trade_gates_pending", "gross_profit", "clean_a4_daily_report" },
                new List<string> { "date", "doc_no", "party_name", "doc_type", "amount_currency", "payment_status", "delivery_status", "running_balance" }
            ),
            WorkspaceExperienceMode.Professional => (
                TerminologyStyle.StrictAccounting,
                UiDensity.Compact,
                6,
                new List<string> { "trial_balance_variance", "coa_tree_navigator", "journal_debit_credit", "ifrs15_contract_liabilities", "fifo_cost_layers", "fx_gain_loss_spread", "audit_sha256_hash", "all_cashiers_z_reports" },
                new List<string> { "entry_date", "doc_no", "coa_code", "account_name", "party_uid", "tx_currency", "tx_debit", "tx_credit", "fx_rate", "base_debit", "base_credit", "weighted_avg_cost", "audit_sha256_hash" }
            ),
            WorkspaceExperienceMode.Executive => (
                TerminologyStyle.Balanced,
                UiDensity.Comfortable,
                4,
                new List<string> { "branch_consolidated_pnl", "multi_currency_cashflow_kpi", "all_cashiers_z_reports", "exception_variance_alerts", "credit_aging_buckets", "trust_score_trend" },
                new List<string> { "branch_name", "revenue_base", "gross_profit", "net_profit", "cash_variance", "overdue_ar", "trust_score" }
            ),
            WorkspaceExperienceMode.ExpressField => (
                TerminologyStyle.SimpleTrade,
                UiDensity.Spacious,
                3,
                new List<string> { "offline_sync_outbox_strip", "assigned_vehicle_custody", "quick_delivery_scan", "cash_collection_counter" },
                new List<string> { "customer_name", "qty_delivered", "cash_collected", "sync_status" }
            ),
            _ => throw new ArgumentOutOfRangeException(nameof(mode))
        };
    }
}
