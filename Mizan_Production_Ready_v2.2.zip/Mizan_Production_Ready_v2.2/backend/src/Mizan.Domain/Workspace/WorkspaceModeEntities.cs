namespace Mizan.Domain.Workspace;

public static class WorkspaceFeatureKeys
{
    public const string WorkspaceExperienceModes = "WORKSPACE_EXPERIENCE_MODES";
}

public enum WorkspaceExperienceMode
{
    Easy,          // الوضع السهل — بطاقات كبيرة ومصطلحات تجارية مبسطة بدون تعقيد محاسبي
    Standard,      // الوضع العادي — توازن كامل للتاجر والمنشآت الصغيرة والمتوسطة
    Professional,  // الوضع الاحترافي — جداول كثيفة، قيود مدين/دائن، شجرة الحسابات، FIFO، بصمات SHA-256
    Executive,     // الوضع التنفيذي — لوحة مؤشرات KPI ومقارنة الفروع والكاشيرات والاستثناءات فقط
    ExpressField   // وضع الميدان السريع — تسليم وعهدة وتحصيل بيد واحدة والعمل دون إنترنت
}

public enum TerminologyStyle
{
    SimpleTrade,      // لك / عليك / دخل / خرج
    Balanced,         // ذمم / فواتير / أرصدة / صافي الربح
    StrictAccounting  // مدين / دائن / التزام عقدي IFRS 15 / تكلفة IAS 2 / فروقات IAS 21
}

public enum UiDensity
{
    Spacious,    // بطاقات واسعة ومسافات كبيرة
    Comfortable, // متوسط ومتوازن
    Compact      // جداول مالية كثيفة متعددة الأعمدة
}

public sealed record OrgRoleModePolicy(
    Guid OrgId,
    string Role,
    WorkspaceExperienceMode DefaultMode,
    bool AllowUserOverride,
    IReadOnlyList<WorkspaceExperienceMode> AllowedModes
);

public sealed record ResolvedWorkspaceProfile(
    WorkspaceExperienceMode EffectiveMode,
    bool WasClampedByRoleOrPolicy,
    string? ClampReason,
    TerminologyStyle Terminology,
    UiDensity Density,
    int MinTouchTargetDp,
    int MaxBottomNavItems,
    bool HideEmptyPrintRows,
    IReadOnlyList<string> VisibleWidgets,
    IReadOnlyList<string> VisibleTableColumns,
    IReadOnlyList<string> HiddenSensitiveFields
);
