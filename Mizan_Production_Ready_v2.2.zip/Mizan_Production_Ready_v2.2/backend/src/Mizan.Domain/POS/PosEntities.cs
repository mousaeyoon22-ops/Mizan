namespace Mizan.Domain.POS;

public static class PosFeatureKeys
{
    public const string PosMultiCashierTouch = "POS_MULTI_CASHIER_TOUCH";
    public const string PosShiftsAndZReport  = "POS_SHIFTS_AND_Z_REPORT";
    public const string ItemVariantsMatrix   = "ITEM_VARIANTS_MATRIX";
}

public enum ShiftStatus { Open, Closed }

public sealed class PosTerminal
{
    public Guid Id { get; init; } = Guid.NewGuid();
    public Guid OrgId { get; init; }
    public string TerminalCode { get; init; } = string.Empty;
    public string DisplayName { get; init; } = string.Empty;
    public Guid CashAccountId { get; init; }
    public int PrinterWidthMm { get; init; } = 80;
    public bool HasCashDrawer { get; init; } = true;
}

public sealed class ItemVariant
{
    public Guid Id { get; init; } = Guid.NewGuid();
    public Guid OrgId { get; init; }
    public Guid ParentItemId { get; init; }
    public string VariantSku { get; init; } = string.Empty;
    public string VariantBarcode { get; init; } = string.Empty;
    public string? SizeLabel { get; init; }
    public string? ColorLabel { get; init; }
    public string? ColorHex { get; init; }
    public decimal SalePrice { get; set; }
    public string Currency { get; init; } = "USD";
    public decimal QtyOnHand { get; set; }
    public int RowVersion { get; set; } = 1;
}

public sealed class PosShift
{
    public Guid Id { get; init; } = Guid.NewGuid();
    public Guid OrgId { get; init; }
    public Guid TerminalId { get; init; }
    public Guid CashierUserId { get; init; }
    public string Currency { get; init; } = "USD";
    public ShiftStatus Status { get; set; } = ShiftStatus.Open;
    public DateTimeOffset OpenedAt { get; init; } = DateTimeOffset.UtcNow;
    public DateTimeOffset? ClosedAt { get; set; }
    public decimal OpeningFloat { get; init; }
    public decimal TotalCashSales { get; set; }
    public decimal TotalCardSales { get; set; }
    public decimal TotalCreditSales { get; set; }
    public decimal TotalCashRefunds { get; set; }
    public decimal? ExpectedCash { get; set; }
    public decimal? CountedCash { get; set; }
    public decimal? CashVariance { get; set; }
    public string? ZReportNumber { get; set; }
    public string? ZReportSha256 { get; set; }
    public Guid? VarianceJournalId { get; set; }
}

public sealed record ZReportSummary(
    string ZReportNumber,
    Guid ShiftId,
    Guid TerminalId,
    Guid CashierUserId,
    string Currency,
    decimal OpeningFloat,
    decimal TotalCashSales,
    decimal TotalCardSales,
    decimal TotalCreditSales,
    decimal TotalCashRefunds,
    decimal ExpectedCash,
    decimal CountedCash,
    decimal CashVariance,
    string ZReportSha256,
    Guid? VarianceJournalId
);
