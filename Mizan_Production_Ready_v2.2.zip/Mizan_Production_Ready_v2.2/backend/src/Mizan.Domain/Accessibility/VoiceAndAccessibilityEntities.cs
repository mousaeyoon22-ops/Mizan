namespace Mizan.Domain.Accessibility;

public static class AccessibilityFeatureKeys
{
    public const string AccessibilityInclusiveMode = "ACCESSIBILITY_INCLUSIVE_MODE";
    public const string VoiceCommandOperations     = "VOICE_COMMAND_OPERATIONS";
}

public enum AccessibilityPreset
{
    Standard,
    BlindScreenReader,
    LowVisionHighContrast,
    DeafVisualHaptic,
    MotorHandsFreeVoice,
    CognitiveSimplified,
    Custom
}

public enum VoiceIntent
{
    Navigate,
    QueryBalance,
    QueryStock,
    ReadLastInvoice,
    CreateSaleInvoice,
    RecordCashReceipt,
    RecordCashPayment,
    PosAddItem,
    OpenShift,
    CloseShift,
    Unknown
}

public enum VoiceCommandState
{
    ExecutedReadOnly,
    DraftAwaitingConfirm,
    ConfirmedAndPosted,
    CancelledByUser,
    RejectedAmbiguous
}

public enum VoiceConfirmationMethod
{
    None,
    VoiceExplicit,
    TouchButton,
    PinOrBiometric
}

public sealed class UserAccessibilityProfile
{
    public Guid UserId { get; init; }
    public AccessibilityPreset Preset { get; set; } = AccessibilityPreset.Standard;
    public bool HighContrastEnabled { get; set; }
    public decimal FontScale { get; set; } = 1.00m;
    public bool ColorBlindSafeLabels { get; set; } = true;
    public bool ScreenReaderVerbose { get; set; }
    public bool TtsFinancialReadback { get; set; }
    public bool VisualFlashAlerts { get; set; }
    public bool HapticFeedbackEnabled { get; set; } = true;
    public bool LiveCaptionsEnabled { get; set; }
    public bool MotorLargeTargets { get; set; }
    public bool SingleTapNoSwipe { get; set; }
    public bool SimplifiedUiMode { get; set; }
    public decimal TimeoutMultiplier { get; set; } = 1.00m;
    public bool VoiceCommandsEnabled { get; set; }
    public string VoiceLang { get; set; } = "ar";
    public decimal VoiceHighValueThreshold { get; set; } = 500.0000m;
}

public sealed class VoiceCommandRecord
{
    public Guid Id { get; init; } = Guid.NewGuid();
    public Guid OrgId { get; init; }
    public Guid UserId { get; init; }
    public string IdempotencyKey { get; init; } = string.Empty;
    public string CommandLang { get; init; } = "ar";
    public string RawTranscript { get; init; } = string.Empty;
    public string TranscriptSha256 { get; init; } = string.Empty;
    public VoiceIntent Intent { get; init; }
    public bool IsFinancialMutation { get; init; }
    public decimal? AmountValue { get; init; }
    public string? Currency { get; init; }
    public string? TargetEntityName { get; init; }
    public string ReadBackPromptAr { get; init; } = string.Empty;
    public string ReadBackPromptEn { get; init; } = string.Empty;
    public VoiceCommandState State { get; set; }
    public VoiceConfirmationMethod ConfirmationMethod { get; set; } = VoiceConfirmationMethod.None;
    public Guid? LinkedJournalId { get; set; }
    public DateTimeOffset CreatedAt { get; init; } = DateTimeOffset.UtcNow;
    public DateTimeOffset? ConfirmedAt { get; set; }
}
