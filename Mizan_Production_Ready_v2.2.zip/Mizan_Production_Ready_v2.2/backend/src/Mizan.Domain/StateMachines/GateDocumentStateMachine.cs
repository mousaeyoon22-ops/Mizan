using Mizan.Domain.Entities;

namespace Mizan.Domain.StateMachines;

public static class GateDocumentStateMachine
{
    private static readonly Dictionary<GateDocState, GateDocState[]> AllowedTransitions = new()
    {
        [GateDocState.Draft]       = new[] { GateDocState.Sent },
        [GateDocState.Sent]        = new[] { GateDocState.UnderReview, GateDocState.Disputed, GateDocState.Approved },
        [GateDocState.UnderReview] = new[] { GateDocState.Disputed, GateDocState.Approved },
        [GateDocState.Disputed]    = new[] { GateDocState.UnderReview, GateDocState.Approved },
        [GateDocState.Approved]    = new[] { GateDocState.Posted },
        [GateDocState.Posted]      = Array.Empty<GateDocState>() // Terminal immutable state
    };

    public static void Transition(GateDocument doc, GateDocState target)
    {
        if (!AllowedTransitions[doc.State].Contains(target))
            throw new InvalidOperationException($"Illegal GateDocument transition: {doc.State} -> {target}");
        doc.State = target;
    }
}
