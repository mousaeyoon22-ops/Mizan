using Mizan.Domain.Entities;

namespace Mizan.Domain.StateMachines;

public static class P2POrderStateMachine
{
    private static readonly Dictionary<P2POrderState, P2POrderState[]> AllowedTransitions = new()
    {
        [P2POrderState.LiveCart]         = new[] { P2POrderState.Submitted, P2POrderState.Cancelled },
        [P2POrderState.Submitted]        = new[] { P2POrderState.SellerAccepted, P2POrderState.Cancelled },
        [P2POrderState.SellerAccepted]   = new[] { P2POrderState.ReadyForHandover, P2POrderState.Cancelled },
        [P2POrderState.ReadyForHandover] = new[] { P2POrderState.Inspecting, P2POrderState.Cancelled },
        [P2POrderState.Inspecting]       = new[] { P2POrderState.Completed, P2POrderState.Disputed, P2POrderState.Cancelled },
        [P2POrderState.Disputed]         = new[] { P2POrderState.Completed, P2POrderState.Cancelled },
        [P2POrderState.Completed]        = Array.Empty<P2POrderState>(),
        [P2POrderState.Cancelled]        = Array.Empty<P2POrderState>()
    };

    public static void Transition(P2POrder order, P2POrderState target)
    {
        if (!AllowedTransitions[order.State].Contains(target))
            throw new InvalidOperationException($"Illegal P2POrder transition: {order.State} -> {target}");
        order.State = target;
    }
}
