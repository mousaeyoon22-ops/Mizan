namespace Mizan.Domain.FX;

public sealed record ExchangeRateQuote(
    string FromCurrency,
    string ToCurrency,
    decimal Rate,
    string RateType,
    DateTimeOffset EffectiveAt
);

public sealed class DualCurrencyJournalLine
{
    public Guid Id { get; init; } = Guid.NewGuid();
    public Guid OrgId { get; init; }
    public Guid AccountId { get; init; }
    public Guid? PartyOrgId { get; init; }
    public string TransactionCurrency { get; init; } = "USD";
    public decimal ExchangeRateToBase { get; init; } = 1.0m;
    public decimal TxDebit { get; init; }
    public decimal TxCredit { get; init; }
    public decimal BaseDebit { get; init; }
    public decimal BaseCredit { get; init; }

    public void Validate()
    {
        if (ExchangeRateToBase <= 0m)
            throw new ArgumentOutOfRangeException(nameof(ExchangeRateToBase));
        if (TxDebit < 0m || TxCredit < 0m || BaseDebit < 0m || BaseCredit < 0m)
            throw new InvalidOperationException("Amounts must be non-negative.");
        if ((BaseDebit > 0m && BaseCredit > 0m) || (BaseDebit == 0m && BaseCredit == 0m))
            throw new InvalidOperationException("Line must carry strictly either BaseDebit or BaseCredit.");
    }
}

public sealed class DualCurrencyJournalEntry
{
    public Guid Id { get; init; } = Guid.NewGuid();
    public Guid OrgId { get; init; }
    public string IdempotencyKey { get; init; } = string.Empty;
    public string ReferenceType { get; init; } = string.Empty;
    public Guid ReferenceId { get; init; }
    public string BaseCurrency { get; init; } = "USD";
    public string Description { get; init; } = string.Empty;
    public DateTimeOffset EntryDate { get; init; } = DateTimeOffset.UtcNow;

    private readonly List<DualCurrencyJournalLine> _lines = new();
    public IReadOnlyList<DualCurrencyJournalLine> Lines => _lines.AsReadOnly();

    public void AddLine(DualCurrencyJournalLine line)
    {
        if (line.OrgId != OrgId)
            throw new UnauthorizedAccessException("BOLA Blocked: Cross-tenant FX line injection.");
        line.Validate();
        _lines.Add(line);
    }

    public void EnsureBaseCurrencyBalanced()
    {
        if (_lines.Count < 2)
            throw new InvalidOperationException("Journal entry must have at least 2 lines.");

        var totalBaseDr = _lines.Sum(l => Math.Round(l.BaseDebit, 4, MidpointRounding.AwayFromZero));
        var totalBaseCr = _lines.Sum(l => Math.Round(l.BaseCredit, 4, MidpointRounding.AwayFromZero));

        if (totalBaseDr != totalBaseCr)
            throw new InvalidOperationException($"IAS21_BASE_BALANCE_VIOLATION: BaseDr={totalBaseDr} != BaseCr={totalBaseCr}");
    }
}

public sealed record FxCalculationSummary(
    DualCurrencyJournalEntry Entry,
    decimal FxDiffBaseAmount, // > 0 Gain (ربح مصارفة), < 0 Loss (خسارة/فرق مصارفة)
    string BaseCurrency
);
