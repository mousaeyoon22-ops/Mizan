namespace Mizan.Domain.Entities;

public enum PairingStatus { Pending, Active, Suspended, Revoked }
public enum GateType { LoadingCustody, SalesReturns, ExpensesFuel, CashRemittance, SharedStatement }
public enum GateStatus { Pending, Active, Paused, Closed }
public enum GateDocState { Draft, Sent, UnderReview, Disputed, Approved, Posted }

public sealed class Pairing
{
    public Guid Id { get; init; } = Guid.NewGuid();
    public Guid OrgAId { get; init; }
    public Guid OrgBId { get; init; }
    public PairingStatus Status { get; set; } = PairingStatus.Pending;
    public Guid RequestedBy { get; init; }
    public Guid? ApprovedBy { get; set; }
    public DateTimeOffset CreatedAt { get; init; } = DateTimeOffset.UtcNow;
}

public sealed class TradeGate
{
    public Guid Id { get; init; } = Guid.NewGuid();
    public Guid PairingId { get; init; }
    public GateType Type { get; init; }
    public Guid SenderOrgId { get; init; }
    public Guid ReceiverOrgId { get; init; }
    public bool ApprovedBySender { get; set; }
    public bool ApprovedByReceiver { get; set; }
    public GateStatus Status
    {
        get => (ApprovedBySender && ApprovedByReceiver) ? GateStatus.Active : GateStatus.Pending;
        private set { _ = value; } // Setter for EF Core materialization
    }
    public DateTimeOffset CreatedAt { get; init; } = DateTimeOffset.UtcNow;
}

public sealed class GateDocument
{
    public Guid Id { get; init; } = Guid.NewGuid();
    public Guid GateId { get; init; }
    public string IdempotencyKey { get; init; } = string.Empty;
    public string DocType { get; init; } = string.Empty;
    public string UblPayloadJson { get; init; } = "{}";
    public string PayloadSha256 { get; init; } = string.Empty;
    public GateDocState State { get; set; } = GateDocState.Draft;
    public Guid? SenderJournalId { get; set; }
    public Guid? ReceiverJournalId { get; set; }
    public DateTimeOffset CreatedAt { get; init; } = DateTimeOffset.UtcNow;
    public DateTimeOffset UpdatedAt { get; set; } = DateTimeOffset.UtcNow;
}
