namespace Mizan.Domain.Entities;

public sealed class InventoryFifoLayer
{
    public Guid Id { get; init; } = Guid.NewGuid();
    public Guid OrgId { get; init; }
    public Guid ItemId { get; init; }
    public Guid SourceDocId { get; init; }
    public DateTimeOffset ReceivedAt { get; init; } = DateTimeOffset.UtcNow;
    public decimal UnitCost { get; init; }
    public decimal QtyOriginal { get; init; }
    public decimal QtyRemaining { get; set; }
}

public sealed class InventoryItem
{
    public Guid Id { get; init; } = Guid.NewGuid();
    public Guid OrgId { get; init; }
    public string Sku { get; init; } = string.Empty;
    public string Name { get; init; } = string.Empty;
    public decimal SalePrice { get; set; }
    public string Currency { get; init; } = "USD";
    public bool IsPerishable { get; init; }
    public int DisputeWindowMinutes => IsPerishable ? 30 : 1440;
    public decimal QtyOnHand { get; set; }
    public decimal QtyReserved { get; set; }
    public decimal WeightedAvgCost { get; set; }
    public int RowVersion { get; set; } = 1;
}
