namespace Mizan.Domain.Entities;

public enum AccountType { Asset, Liability, Equity, Revenue, Expense }
public enum InventoryValuationMethod { Fifo, WeightedAverage }

public sealed class Account
{
    public Guid Id { get; init; } = Guid.NewGuid();
    public Guid OrgId { get; init; }
    public string Code { get; init; } = string.Empty;
    public string Name { get; init; } = string.Empty;
    public AccountType Type { get; init; }
    public string Currency { get; init; } = "USD";
    public bool IsActive { get; set; } = true;
}

/// <summary>
/// Fixes DEF-303: Includes BaseDebit and BaseCredit so every line satisfies PostgreSQL
/// Migration 005 constraint `chk_base_mirrors_tx_side` and IAS 21 functional-currency balance.
/// </summary>
public sealed class JournalLine
{
    public Guid Id { get; init; } = Guid.NewGuid();
    public Guid JournalEntryId { get; set; }
    public Guid OrgId { get; init; }
    public Guid AccountId { get; init; }
    public Guid? PartyOrgId { get; init; }
    public decimal Debit { get; init; }
    public decimal Credit { get; init; }
    public decimal BaseDebit { get; set; }
    public decimal BaseCredit { get; set; }

    public void Validate()
    {
        if (Debit < 0m || Credit < 0m || BaseDebit < 0m || BaseCredit < 0m)
            throw new InvalidOperationException("Debit, Credit, BaseDebit and BaseCredit must be non-negative.");
        if ((Debit > 0m && Credit > 0m) || (Debit == 0m && Credit == 0m))
            throw new InvalidOperationException("A journal line must carry strictly either a Debit or a Credit.");
        if ((Debit > 0m && (BaseDebit <= 0m || BaseCredit != 0m)) || (Credit > 0m && (BaseCredit <= 0m || BaseDebit != 0m)))
            throw new InvalidOperationException("BaseDebit/BaseCredit must strictly mirror Debit/Credit side.");
    }
}

public sealed class JournalEntry
{
    public Guid Id { get; init; } = Guid.NewGuid();
    public Guid OrgId { get; init; }
    public string IdempotencyKey { get; init; } = string.Empty;
    public string ReferenceType { get; init; } = string.Empty;
    public Guid ReferenceId { get; init; }
    public DateTimeOffset EntryDate { get; init; } = DateTimeOffset.UtcNow;
    public string Description { get; init; } = string.Empty;
    public string Currency { get; init; } = "USD";
    public decimal ExchangeRate { get; init; } = 1.0m;
    public string Status { get; private set; } = "POSTED";
    public bool IsReversed => Status == "REVERSED";
    public Guid? ReversedById { get; private set; }
    public Guid CreatedBy { get; init; } = Guid.Empty;
    public DateTimeOffset CreatedAt { get; init; } = DateTimeOffset.UtcNow;

    private readonly List<JournalLine> _lines = new();
    public IReadOnlyList<JournalLine> Lines => _lines.AsReadOnly();

    public void AddLine(JournalLine line)
    {
        if (line.OrgId != OrgId)
            throw new UnauthorizedAccessException("Cross-tenant journal line injection blocked.");
        line.JournalEntryId = Id;
        // Populate functional base-currency amounts automatically if not explicitly supplied
        if (line.Debit > 0m && line.BaseDebit == 0m)
            line.BaseDebit = Math.Round(line.Debit * ExchangeRate, 4, MidpointRounding.AwayFromZero);
        if (line.Credit > 0m && line.BaseCredit == 0m)
            line.BaseCredit = Math.Round(line.Credit * ExchangeRate, 4, MidpointRounding.AwayFromZero);

        line.Validate();
        _lines.Add(line);
    }

    public void EnsureBalanced()
    {
        if (_lines.Count < 2)
            throw new InvalidOperationException("Journal entry must contain at least 2 lines.");

        var totalDebit = _lines.Sum(l => Math.Round(l.Debit, 4, MidpointRounding.AwayFromZero));
        var totalCredit = _lines.Sum(l => Math.Round(l.Credit, 4, MidpointRounding.AwayFromZero));
        var totalBaseDebit = _lines.Sum(l => Math.Round(l.BaseDebit, 4, MidpointRounding.AwayFromZero));
        var totalBaseCredit = _lines.Sum(l => Math.Round(l.BaseCredit, 4, MidpointRounding.AwayFromZero));

        if (totalDebit != totalCredit)
            throw new InvalidOperationException($"Unbalanced journal entry: Debit={totalDebit}, Credit={totalCredit}.");
        if (totalBaseDebit != totalBaseCredit)
            throw new InvalidOperationException($"Unbalanced base-currency journal entry: BaseDebit={totalBaseDebit}, BaseCredit={totalBaseCredit}.");
    }

    public JournalEntry CreateReversal(string reversalIdempotencyKey, string reason)
    {
        if (IsReversed)
            throw new InvalidOperationException("Journal entry has already been reversed.");

        var reversal = new JournalEntry
        {
            OrgId = OrgId,
            IdempotencyKey = reversalIdempotencyKey,
            ReferenceType = "REVERSAL",
            ReferenceId = Id,
            Description = $"Reversal of {Id}: {reason}",
            Currency = Currency,
            ExchangeRate = ExchangeRate,
            CreatedBy = CreatedBy
        };

        foreach (var line in _lines)
        {
            reversal.AddLine(new JournalLine
            {
                OrgId = OrgId,
                AccountId = line.AccountId,
                PartyOrgId = line.PartyOrgId,
                Debit = line.Credit,
                Credit = line.Debit,
                BaseDebit = line.BaseCredit,
                BaseCredit = line.BaseDebit
            });
        }

        reversal.EnsureBalanced();
        Status = "REVERSED";
        ReversedById = reversal.Id;
        return reversal;
    }
}
