namespace Mizan.Domain.Entities;

public enum PaymentMode { GatewayPreAuth, Cash, Credit, PartialCredit }
public enum PaymentStatus { Unpaid, PreAuthorized, PartiallyPaid, Captured, Voided }
public enum DeliveryStatus { Pending, PartiallyDelivered, Delivered, Returned }
public enum P2POrderState { LiveCart, Submitted, SellerAccepted, ReadyForHandover, Inspecting, Completed, Cancelled, Disputed }
public enum FaultParty { Seller, Buyer, Neutral }

public sealed class P2POrder
{
    public Guid Id { get; init; } = Guid.NewGuid();
    public string IdempotencyKey { get; init; } = string.Empty;
    public Guid SellerOrgId { get; init; }
    public Guid BuyerUserId { get; init; }
    public Guid? BuyerOrgId { get; init; }
    public PaymentMode PaymentMode { get; set; }
    public PaymentStatus PaymentStatus { get; set; } = PaymentStatus.Unpaid;
    public DeliveryStatus DeliveryStatus { get; set; } = DeliveryStatus.Pending;
    public P2POrderState State { get; set; } = P2POrderState.LiveCart;
    public string Currency { get; init; } = "USD";
    public decimal TotalAmount { get; set; }
    public decimal PaidAmount { get; set; }
    public string? GatewayAuthRef { get; set; }
    public DateTimeOffset? HoldExpiresAt { get; set; }
    public DateTimeOffset? DeliveredAt { get; set; }
    public string? CancelReasonCode { get; set; }
    public FaultParty? CancelFaultParty { get; set; }
    public DateTimeOffset CreatedAt { get; init; } = DateTimeOffset.UtcNow;
}

public sealed class BlindRating
{
    public Guid Id { get; init; } = Guid.NewGuid();
    public Guid OrderId { get; init; }
    public string RaterRole { get; init; } = string.Empty; // BUYER | SELLER
    public Guid RaterUserId { get; init; }
    public short Score { get; init; }
    public string? Comment { get; init; }
    public bool IsPublished { get; set; }
    public DateTimeOffset RevealAfter { get; init; } = DateTimeOffset.UtcNow.AddDays(7);
    public DateTimeOffset CreatedAt { get; init; } = DateTimeOffset.UtcNow;
}
