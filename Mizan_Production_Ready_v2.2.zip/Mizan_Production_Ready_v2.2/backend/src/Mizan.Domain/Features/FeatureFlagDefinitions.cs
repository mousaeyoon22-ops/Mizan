namespace Mizan.Domain.Features;

public enum FeatureCategory { Core, Commerce, Compliance, Integration, Ai, Fintech }

public static class MizanFeatureKeys
{
    // Phase 1 Active Core (10 keys)
    public const string CoreDoubleEntryLedger          = "CORE_DOUBLE_ENTRY_LEDGER";
    public const string OfflineSqliteOutbox            = "OFFLINE_SQLITE_OUTBOX";
    public const string AccessibilityInclusiveMode     = "ACCESSIBILITY_INCLUSIVE_MODE";
    public const string TradeGatesExchange             = "TRADE_GATES_EXCHANGE";
    public const string QrCatalogSelfCheckout          = "QR_CATALOG_SELF_CHECKOUT";
    public const string MultiLanguageUi                = "MULTI_LANGUAGE_UI";
    public const string MultiCurrencyLedger            = "MULTI_CURRENCY_LEDGER";
    public const string FxIas21GainLossEngine          = "FX_IAS21_GAIN_LOSS_ENGINE";
    public const string DirectCurrencyExchangeVoucher  = "DIRECT_CURRENCY_EXCHANGE_VOUCHER";
    public const string WorkspaceExperienceModes       = "WORKSPACE_EXPERIENCE_MODES";

    // Phase 1 Embedded Optional (8 keys — OFF by default, org configurable)
    public const string ContextualTransactionChat      = "CONTEXTUAL_TRANSACTION_CHAT";
    public const string PublicNearbyDirectory          = "PUBLIC_NEARBY_DIRECTORY";
    public const string BlindMutualRatings             = "BLIND_MUTUAL_RATINGS";
    public const string PerishableLiveCamDisputes      = "PERISHABLE_LIVE_CAM_DISPUTES";
    public const string PosMultiCashierTouch           = "POS_MULTI_CASHIER_TOUCH";
    public const string PosShiftsAndZReport            = "POS_SHIFTS_AND_Z_REPORT";
    public const string ItemVariantsMatrix             = "ITEM_VARIANTS_MATRIX";
    public const string VoiceCommandOperations         = "VOICE_COMMAND_OPERATIONS";

    // Phase 2 & 3 Platform-Locked Extensions (7 keys — OFF by default)
    public const string KycStrictTiers2To4             = "KYC_STRICT_TIERS_2_TO_4";
    public const string PspPassThroughPreAuth          = "PSP_PASS_THROUGH_PREAUTH";
    public const string TaxEInvoicingPeppolZatca       = "TAX_EINVOICING_PEPPOL_ZATCA";
    public const string InstantCrossBorderTranslation  = "INSTANT_CROSS_BORDER_TRANSLATION";
    public const string ErpConnectorsOAuth             = "ERP_CONNECTORS_OAUTH";
    public const string AiFinancialCopilotOcr          = "AI_FINANCIAL_COPILOT_OCR";
    public const string InternalWalletCustody          = "INTERNAL_WALLET_CUSTODY";

    public static IReadOnlyList<FeatureDefinition> Phase1DefaultRegistry() => new List<FeatureDefinition>
    {
        // Active Core (10)
        new(CoreDoubleEntryLedger,         FeatureCategory.Core,        1, true,  true,  false, true,  null),
        new(OfflineSqliteOutbox,           FeatureCategory.Core,        1, true,  true,  false, true,  null),
        new(AccessibilityInclusiveMode,    FeatureCategory.Core,        1, true,  true,  false, true,  null),
        new(TradeGatesExchange,            FeatureCategory.Core,        1, false, true,  true,  true,  CoreDoubleEntryLedger),
        new(QrCatalogSelfCheckout,         FeatureCategory.Commerce,    1, false, true,  true,  true,  CoreDoubleEntryLedger),
        new(MultiLanguageUi,               FeatureCategory.Core,        1, false, true,  true,  true,  null),
        new(MultiCurrencyLedger,           FeatureCategory.Core,        1, false, true,  true,  true,  CoreDoubleEntryLedger),
        new(FxIas21GainLossEngine,         FeatureCategory.Core,        1, false, true,  true,  true,  MultiCurrencyLedger),
        new(DirectCurrencyExchangeVoucher, FeatureCategory.Core,        1, false, true,  true,  true,  FxIas21GainLossEngine),
        new(WorkspaceExperienceModes,      FeatureCategory.Core,        1, false, true,  true,  true,  CoreDoubleEntryLedger),

        // Phase 1 Embedded Optional — OFF by default (8)
        new(ContextualTransactionChat,     FeatureCategory.Commerce,    1, false, true,  true,  false, TradeGatesExchange),
        new(PublicNearbyDirectory,         FeatureCategory.Commerce,    1, false, true,  true,  false, QrCatalogSelfCheckout),
        new(BlindMutualRatings,            FeatureCategory.Commerce,    1, false, true,  true,  false, QrCatalogSelfCheckout),
        new(PerishableLiveCamDisputes,     FeatureCategory.Commerce,    1, false, true,  true,  false, QrCatalogSelfCheckout),
        new(PosMultiCashierTouch,          FeatureCategory.Commerce,    1, false, true,  true,  false, CoreDoubleEntryLedger),
        new(PosShiftsAndZReport,           FeatureCategory.Commerce,    1, false, true,  true,  false, PosMultiCashierTouch),
        new(ItemVariantsMatrix,            FeatureCategory.Commerce,    1, false, true,  true,  false, CoreDoubleEntryLedger),
        new(VoiceCommandOperations,        FeatureCategory.Core,        1, false, true,  true,  false, AccessibilityInclusiveMode),

        // Phase 2 & 3 Platform-Locked — OFF by default (7)
        new(KycStrictTiers2To4,            FeatureCategory.Compliance,  2, false, false, true,  false, null),
        new(PspPassThroughPreAuth,         FeatureCategory.Fintech,     2, false, false, true,  false, KycStrictTiers2To4),
        new(TaxEInvoicingPeppolZatca,      FeatureCategory.Compliance,  2, false, false, true,  false, CoreDoubleEntryLedger),
        new(InstantCrossBorderTranslation, FeatureCategory.Ai,          2, false, false, true,  false, MultiLanguageUi),
        new(ErpConnectorsOAuth,            FeatureCategory.Integration, 3, false, false, true,  false, TradeGatesExchange),
        new(AiFinancialCopilotOcr,         FeatureCategory.Ai,          3, false, false, true,  false, CoreDoubleEntryLedger),
        new(InternalWalletCustody,         FeatureCategory.Fintech,     3, false, false, false, false, KycStrictTiers2To4)
    };
}

public sealed record FeatureDefinition(
    string Key,
    FeatureCategory Category,
    int ReleasePhase,
    bool IsImmutableCore,
    bool PlatformEnabled,
    bool OrgConfigurable,
    bool DefaultOrgState,
    string? RequiresFeature
);
