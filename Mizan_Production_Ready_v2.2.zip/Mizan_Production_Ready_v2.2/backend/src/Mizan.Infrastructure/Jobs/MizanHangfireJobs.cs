using Microsoft.EntityFrameworkCore;
using Mizan.Domain.Entities;
using Mizan.Infrastructure.Persistence;

namespace Mizan.Infrastructure.Jobs;

/// <summary>
/// Fixes DEF-305: Real PostgreSQL-backed Hangfire automation jobs (backed directly by EF Core + PostgreSQL).
/// </summary>
public sealed class MizanHangfireJobs
{
    private readonly MizanDbContext _db;

    public MizanHangfireJobs(MizanDbContext db) => _db = db;

    public async Task<int> ReleaseExpiredInventoryHoldsAsync(CancellationToken ct = default)
    {
        var now = DateTimeOffset.UtcNow;
        var expired = await _db.P2POrders
            .Where(o => (o.State == P2POrderState.LiveCart || o.State == P2POrderState.Submitted)
                        && o.HoldExpiresAt != null && o.HoldExpiresAt <= now)
            .ToListAsync(ct);

        foreach (var order in expired)
        {
            order.State = P2POrderState.Cancelled;
            order.CancelReasonCode = "HOLD_TIMEOUT_EXPIRED";
            order.CancelFaultParty = FaultParty.Neutral;
        }
        return expired.Count > 0 ? await _db.SaveChangesAsync(ct) : 0;
    }

    public async Task<int> PublishMaturedBlindRatingsAsync(CancellationToken ct = default)
    {
        var now = DateTimeOffset.UtcNow;
        var matured = await _db.BlindRatings
            .Where(r => !r.IsPublished && r.RevealAfter <= now)
            .ToListAsync(ct);

        foreach (var r in matured)
            r.IsPublished = true;

        return matured.Count > 0 ? await _db.SaveChangesAsync(ct) : 0;
    }
}
