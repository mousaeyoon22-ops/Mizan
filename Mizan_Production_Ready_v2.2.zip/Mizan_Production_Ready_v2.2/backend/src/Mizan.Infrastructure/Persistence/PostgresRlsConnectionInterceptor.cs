using System.Data.Common;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Mizan.Infrastructure.Security;

namespace Mizan.Infrastructure.Persistence;

/// <summary>
/// Fixes DEF-002 (P0 RLS Binding):
/// Automatically sets PostgreSQL session variables `app.current_org_id` and `app.current_user_id`
/// on every opened Npgsql connection so database-level Row-Level Security (RLS) is ALWAYS active.
/// </summary>
public sealed class PostgresRlsConnectionInterceptor : DbConnectionInterceptor
{
    private readonly TenantContext _tenant;

    public PostgresRlsConnectionInterceptor(TenantContext tenant) => _tenant = tenant;

    public override async Task ConnectionOpenedAsync(
        DbConnection connection,
        ConnectionEndEventData eventData,
        CancellationToken cancellationToken = default)
    {
        if (!_tenant.IsAuthenticated) return;

        await using var cmd = connection.CreateCommand();
        cmd.CommandText = "SELECT set_config('app.current_org_id', @orgId, false), set_config('app.current_user_id', @userId, false);";

        var pOrg = cmd.CreateParameter();
        pOrg.ParameterName = "@orgId";
        pOrg.Value = _tenant.ActiveOrgId == Guid.Empty ? string.Empty : _tenant.ActiveOrgId.ToString();
        cmd.Parameters.Add(pOrg);

        var pUser = cmd.CreateParameter();
        pUser.ParameterName = "@userId";
        pUser.Value = _tenant.UserId.ToString();
        cmd.Parameters.Add(pUser);

        await cmd.ExecuteNonQueryAsync(cancellationToken);
    }
}
