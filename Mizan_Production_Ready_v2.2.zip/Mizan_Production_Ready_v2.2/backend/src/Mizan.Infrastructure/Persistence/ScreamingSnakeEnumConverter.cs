using System.Text;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;

namespace Mizan.Infrastructure.Persistence;

/// <summary>
/// Fixes DEF-402 (P0): Converts C# PascalCase enums (e.g. `GatewayPreAuth`, `DraftAwaitingConfirm`)
/// to PostgreSQL uppercase VARCHAR CHECK values (`GATEWAY_PREAUTH`, `DRAFT_AWAITING_CONFIRM`) and back.
/// </summary>
public sealed class ScreamingSnakeEnumConverter<TEnum> : ValueConverter<TEnum, string>
    where TEnum : struct, Enum
{
    private static readonly Dictionary<string, string> SpecialOverrides = new(StringComparer.Ordinal)
    {
        ["GatewayPreAuth"] = "GATEWAY_PREAUTH",
        ["PreAuthorized"]  = "PREAUTHORIZED",
        ["ExecutedReadOnly"] = "EXECUTED_READONLY",
    };

    public ScreamingSnakeEnumConverter()
        : base(v => ToPgString(v), s => FromPgString(s))
    {
    }

    public static string ToPgString(TEnum value)
    {
        var name = value.ToString();
        if (SpecialOverrides.TryGetValue(name, out var mapped)) return mapped;

        var sb = new StringBuilder(name.Length + 6);
        for (int i = 0; i < name.Length; i++)
        {
            var ch = name[i];
            if (i > 0 && char.IsUpper(ch) && (char.IsLower(name[i - 1]) || (i + 1 < name.Length && char.IsLower(name[i + 1]))))
                sb.Append('_');
            sb.Append(char.ToUpperInvariant(ch));
        }
        return sb.ToString();
    }

    public static TEnum FromPgString(string dbVal)
    {
        foreach (var val in Enum.GetValues<TEnum>())
        {
            if (string.Equals(ToPgString(val), dbVal, StringComparison.OrdinalIgnoreCase))
                return val;
        }
        throw new InvalidOperationException($"Cannot convert PostgreSQL enum string '{dbVal}' to {typeof(TEnum).Name}.");
    }
}
