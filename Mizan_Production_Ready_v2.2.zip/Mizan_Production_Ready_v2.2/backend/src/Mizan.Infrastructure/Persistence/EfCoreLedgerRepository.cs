using Microsoft.EntityFrameworkCore;
using Mizan.Application.Persistence;
using Mizan.Domain.Entities;
using Mizan.Infrastructure.Security;

namespace Mizan.Infrastructure.Persistence;

public sealed class EfCoreLedgerRepository : ILedgerRepository, IOrganizationMembershipValidator, IOrderChannelAccessValidator
{
    private readonly MizanDbContext _db;

    public EfCoreLedgerRepository(MizanDbContext db) => _db = db;

    public Task<JournalEntry?> FindByIdempotencyKeyAsync(Guid orgId, string idempotencyKey, CancellationToken ct = default)
        => _db.JournalEntries.FirstOrDefaultAsync(e => e.OrgId == orgId && e.IdempotencyKey == idempotencyKey, ct);

    public async Task SaveJournalEntryAsync(JournalEntry entry, CancellationToken ct = default)
    {
        entry.EnsureBalanced();
        await _db.JournalEntries.AddAsync(entry, ct);
        await _db.SaveChangesAsync(ct);
    }

    public async Task<decimal> GetTrialBalanceVarianceAsync(Guid orgId, CancellationToken ct = default)
    {
        var totals = await _db.JournalLines
            .Where(l => l.OrgId == orgId)
            .GroupBy(_ => 1)
            .Select(g => new { Dr = g.Sum(x => x.Debit), Cr = g.Sum(x => x.Credit) })
            .FirstOrDefaultAsync(ct);

        return totals is null ? 0.0000m : Math.Round(totals.Dr - totals.Cr, 4, MidpointRounding.AwayFromZero);
    }

    public async Task<decimal> GetAccountBalanceAsync(Guid orgId, Guid accountId, CancellationToken ct = default)
    {
        var net = await _db.JournalLines
            .Where(l => l.OrgId == orgId && l.AccountId == accountId)
            .SumAsync(l => l.Debit - l.Credit, ct);
        return Math.Round(net, 4, MidpointRounding.AwayFromZero);
    }

    public async Task<(bool IsMember, string Role)> ValidateMembershipAsync(Guid userId, Guid orgId, CancellationToken ct = default)
    {
        await using var cmd = _db.Database.GetDbConnection().CreateCommand();
        if (cmd.Connection!.State != System.Data.ConnectionState.Open)
            await cmd.Connection.OpenAsync(ct);

        cmd.CommandText = "SELECT role FROM organization_members WHERE user_id = @u AND org_id = @o LIMIT 1;";
        var pu = cmd.CreateParameter(); pu.ParameterName = "@u"; pu.Value = userId; cmd.Parameters.Add(pu);
        var po = cmd.CreateParameter(); po.ParameterName = "@o"; po.Value = orgId; cmd.Parameters.Add(po);

        var result = await cmd.ExecuteScalarAsync(ct);
        return result is string role ? (true, role) : (false, string.Empty);
    }

    public async Task<(bool IsParty, bool IsChatLocked)> ValidateOrderChannelAccessAsync(Guid userId, Guid orgId, Guid orderId, CancellationToken ct = default)
    {
        var order = await _db.P2POrders.AsNoTracking().FirstOrDefaultAsync(o => o.Id == orderId, ct);
        if (order is null) return (false, true);

        var isParty = order.SellerOrgId == orgId || order.BuyerOrgId == orgId || order.BuyerUserId == userId;
        var isLocked = order.State == P2POrderState.Completed || order.State == P2POrderState.Cancelled;
        return (isParty, isLocked);
    }
}
