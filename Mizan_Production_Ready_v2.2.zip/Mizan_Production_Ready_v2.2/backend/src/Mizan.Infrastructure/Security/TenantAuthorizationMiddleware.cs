using System.Security.Claims;
using Microsoft.AspNetCore.Http;

namespace Mizan.Infrastructure.Security;

public sealed class TenantContext
{
    public Guid UserId { get; set; }
    public Guid ActiveOrgId { get; set; }
    public string Role { get; set; } = string.Empty;
    public bool IsAuthenticated => UserId != Guid.Empty;
}

public interface IOrganizationMembershipValidator
{
    Task<(bool IsMember, string Role)> ValidateMembershipAsync(Guid userId, Guid orgId, CancellationToken ct = default);
}

/// <summary>
/// Fixes DEF-002 (P0 BOLA/IDOR):
/// Validates that the authenticated JWT subject (`sub`) is an active member of the requested `X-Org-Id`
/// BEFORE any controller or DbContext executes. Rejects forged X-Org-Id headers with HTTP 403.
/// </summary>
public sealed class TenantAuthorizationMiddleware
{
    private readonly RequestDelegate _next;

    public TenantAuthorizationMiddleware(RequestDelegate next) => _next = next;

    public async Task InvokeAsync(
        HttpContext context,
        TenantContext tenantContext,
        IOrganizationMembershipValidator membershipValidator)
    {
        if (context.Request.Path.StartsWithSegments("/health") ||
            context.Request.Path.StartsWithSegments("/swagger"))
        {
            await _next(context);
            return;
        }

        if (context.User.Identity?.IsAuthenticated == true)
        {
            var subClaim = context.User.FindFirstValue(ClaimTypes.NameIdentifier)
                           ?? context.User.FindFirstValue("sub");

            if (!Guid.TryParse(subClaim, out var userId))
            {
                context.Response.StatusCode = StatusCodes.Status401Unauthorized;
                await context.Response.WriteAsJsonAsync(new { error = "INVALID_TOKEN_SUBJECT" });
                return;
            }

            tenantContext.UserId = userId;

            if (context.Request.Headers.TryGetValue("X-Org-Id", out var orgHeaderValues))
            {
                if (!Guid.TryParse(orgHeaderValues.FirstOrDefault(), out var orgId))
                {
                    context.Response.StatusCode = StatusCodes.Status400BadRequest;
                    await context.Response.WriteAsJsonAsync(new { error = "INVALID_X_ORG_ID_HEADER" });
                    return;
                }

                var (isMember, role) = await membershipValidator.ValidateMembershipAsync(userId, orgId, context.RequestAborted);
                if (!isMember)
                {
                    context.Response.StatusCode = StatusCodes.Status403Forbidden;
                    await context.Response.WriteAsJsonAsync(new
                    {
                        error = "BOLA_TENANT_ACCESS_DENIED",
                        message = "Authenticated user is not an authorized member of the requested organization."
                    });
                    return;
                }

                tenantContext.ActiveOrgId = orgId;
                tenantContext.Role = role;
            }
        }

        await _next(context);
    }
}
