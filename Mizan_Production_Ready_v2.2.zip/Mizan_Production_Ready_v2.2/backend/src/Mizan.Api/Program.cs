using System.Text;
using Hangfire;
using Hangfire.PostgreSql;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.IdentityModel.Tokens;
using Mizan.Api.Hubs;
using Mizan.Api.Security;
using Mizan.Application.Accessibility;
using Mizan.Application.Adapters;
using Mizan.Application.Features;
using Mizan.Application.FX;
using Mizan.Application.Persistence;
using Mizan.Application.POS;
using Mizan.Application.Reports;
using Mizan.Application.Security;
using Mizan.Application.Services;
using Mizan.Application.Translation;
using Mizan.Application.Workspace;
using Mizan.Domain.Features;
using Mizan.Infrastructure.Jobs;
using Mizan.Infrastructure.Persistence;
using Mizan.Infrastructure.Security;

var builder = WebApplication.CreateBuilder(args);

var connStr = builder.Configuration["MIZAN_POSTGRES_CONNECTION"]
    ?? throw new InvalidOperationException("MIZAN_POSTGRES_CONNECTION environment variable is required.");
var jwtSigningKey = builder.Configuration["JWT_SIGNING_KEY"]
    ?? throw new InvalidOperationException("JWT_SIGNING_KEY environment variable is required.");
if (Encoding.UTF8.GetByteCount(jwtSigningKey) < 32)
    throw new InvalidOperationException("JWT_SIGNING_KEY must be at least 32 bytes (256 bits).");

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddSignalR();
builder.Services.AddHealthChecks();

builder.Services
    .AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidIssuer = builder.Configuration["JWT_ISSUER"] ?? "mizan.auth",
            ValidateAudience = true,
            ValidAudience = builder.Configuration["JWT_AUDIENCE"] ?? "mizan.api",
            ValidateIssuerSigningKey = true,
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtSigningKey)),
            ValidateLifetime = true,
            ClockSkew = TimeSpan.FromSeconds(30)
        };
        options.Events = new JwtBearerEvents
        {
            OnMessageReceived = ctx =>
            {
                var accessToken = ctx.Request.Query["access_token"];
                if (!string.IsNullOrEmpty(accessToken) && ctx.HttpContext.Request.Path.StartsWithSegments("/hubs"))
                    ctx.Token = accessToken;
                return Task.CompletedTask;
            }
        };
    });
builder.Services.AddAuthorization();

// Security, RLS & Snake-Case EF Core Persistence (Fixes DEF-302 & DEF-304)
builder.Services.AddSingleton<PasswordAndTokenService>();
builder.Services.AddScoped<TenantContext>();
builder.Services.AddScoped<PostgresRlsConnectionInterceptor>();
builder.Services.AddDbContext<MizanDbContext>((sp, opt) =>
{
    opt.UseNpgsql(connStr)
       .UseSnakeCaseNamingConvention()
       .AddInterceptors(sp.GetRequiredService<PostgresRlsConnectionInterceptor>());
});
builder.Services.AddScoped<EfCoreLedgerRepository>();
builder.Services.AddScoped<ILedgerRepository>(sp => sp.GetRequiredService<EfCoreLedgerRepository>());
builder.Services.AddScoped<IOrganizationMembershipValidator>(sp => sp.GetRequiredService<EfCoreLedgerRepository>());
builder.Services.AddScoped<IOrderChannelAccessValidator>(sp => sp.GetRequiredService<EfCoreLedgerRepository>());

// Unified Domain & Application Engines
builder.Services.AddScoped<DoubleEntryAccountingEngine>();
builder.Services.AddScoped<TradeGateService>();
builder.Services.AddScoped<P2PCommerceService>();
builder.Services.AddScoped<Ias21FxAccountingEngine>();
builder.Services.AddScoped<PosShiftAndZReportService>();
builder.Services.AddScoped<VoiceCommandGovernanceService>();
builder.Services.AddSingleton<WorkspaceModeResolverService>();
builder.Services.AddSingleton<A4CleanReportBuilder>();

// 3-Tier Operational Feature Governance (All 25 unified flags)
builder.Services.AddSingleton(_ => new FeatureGovernanceService(MizanFeatureKeys.Phase1DefaultRegistry()));

// Phase-1 Safe Disabled Hexagonal Adapters
builder.Services.AddSingleton<IPaymentGatewayAdapter, DisabledPaymentGatewayAdapter>();
builder.Services.AddSingleton<ITranslationAdapter, DisabledTranslationAdapter>();
builder.Services.AddScoped(sp =>
{
    var adapter = sp.GetRequiredService<ITranslationAdapter>();
    var gov = sp.GetRequiredService<FeatureGovernanceService>();
    return new InstantTranslationService(adapter, (orgId, key) => gov.IsEnabled(orgId, key));
});

// Scheduled Background Jobs (Hangfire backed by PostgreSQL)
builder.Services.AddScoped<MizanHangfireJobs>();
builder.Services.AddHangfire(cfg => cfg.UsePostgreSqlStorage(opt => opt.UseNpgsqlConnection(connStr)));
builder.Services.AddHangfireServer();

var app = builder.Build();
app.UseMiddleware<GlobalExceptionMiddleware>();
app.UseHttpsRedirection();
app.UseAuthentication();
app.UseMiddleware<TenantAuthorizationMiddleware>();
app.UseAuthorization();
app.MapHealthChecks("/health");
app.MapControllers();
app.MapHub<MizanRealtimeHub>("/hubs/mizan");

// Schedule recurring Hangfire automation jobs (Fixes DEF-405)
using (var scope = app.Services.CreateScope())
{
    var recurring = scope.ServiceProvider.GetRequiredService<IRecurringJobManager>();
    recurring.AddOrUpdate<MizanHangfireJobs>("release-expired-holds", j => j.ReleaseExpiredInventoryHoldsAsync(CancellationToken.None), "*/5 * * * *");
    recurring.AddOrUpdate<MizanHangfireJobs>("publish-matured-blind-ratings", j => j.PublishMaturedBlindRatingsAsync(CancellationToken.None), Cron.Hourly);
}

app.Run();
