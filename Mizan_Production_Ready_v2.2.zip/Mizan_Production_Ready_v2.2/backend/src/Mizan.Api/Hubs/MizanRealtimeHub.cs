using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.SignalR;
using Mizan.Application.Features;
using Mizan.Application.Persistence;
using Mizan.Domain.Features;

namespace Mizan.Api.Hubs;

/// <summary>
/// Fixes DEF-003 (P0 SignalR BOLA):
/// Verifies party ownership of every `orderId` before joining or broadcasting,
/// enforces `CONTEXTUAL_TRANSACTION_CHAT` feature flag, and blocks messages on closed archive orders.
/// </summary>
[Authorize]
public sealed class MizanRealtimeHub : Hub
{
    private readonly IOrderChannelAccessValidator _accessValidator;
    private readonly FeatureGovernanceService _governance;

    public MizanRealtimeHub(IOrderChannelAccessValidator accessValidator, FeatureGovernanceService governance)
    {
        _accessValidator = accessValidator;
        _governance = governance;
    }

    private (Guid UserId, Guid OrgId) ResolveCallerIdentity()
    {
        var sub = Context.User?.FindFirstValue(ClaimTypes.NameIdentifier) ?? Context.User?.FindFirstValue("sub");
        var orgHeader = Context.GetHttpContext()?.Request.Headers["X-Org-Id"].FirstOrDefault();
        if (!Guid.TryParse(sub, out var userId))
            throw new HubException("UNAUTHORIZED_CALLER");
        Guid.TryParse(orgHeader, out var orgId);
        return (userId, orgId);
    }

    public async Task JoinOrderChannel(Guid orderId)
    {
        var (userId, orgId) = ResolveCallerIdentity();
        var (isParty, _) = await _accessValidator.ValidateOrderChannelAccessAsync(userId, orgId, orderId, Context.ConnectionAborted);
        if (!isParty)
            throw new HubException("BOLA_ORDER_CHANNEL_DENIED");

        await Groups.AddToGroupAsync(Context.ConnectionId, $"order:{orderId}");
    }

    public async Task BroadcastCartUpdate(Guid orderId, object cartSnapshot)
    {
        var (userId, orgId) = ResolveCallerIdentity();
        var (isParty, isLocked) = await _accessValidator.ValidateOrderChannelAccessAsync(userId, orgId, orderId, Context.ConnectionAborted);
        if (!isParty) throw new HubException("BOLA_ORDER_CHANNEL_DENIED");
        if (isLocked) throw new HubException("ORDER_CLOSED_IMMUTABLE");

        await Clients.Group($"order:{orderId}").SendAsync("CartUpdated", cartSnapshot);
    }

    public async Task SendTransactionMessage(Guid orderId, string senderRole, string messageBody, string? liveCardRef)
    {
        var (userId, orgId) = ResolveCallerIdentity();
        if (orgId != Guid.Empty && !_governance.IsEnabled(orgId, MizanFeatureKeys.ContextualTransactionChat))
            throw new HubException("FEATURE_DISABLED_BY_POLICY:CONTEXTUAL_TRANSACTION_CHAT");

        var (isParty, isLocked) = await _accessValidator.ValidateOrderChannelAccessAsync(userId, orgId, orderId, Context.ConnectionAborted);
        if (!isParty) throw new HubException("BOLA_ORDER_CHANNEL_DENIED");
        if (isLocked) throw new HubException("TRANSACTION_CHAT_LOCKED_ARCHIVE");

        await Clients.Group($"order:{orderId}").SendAsync("MessageReceived", new
        {
            OrderId = orderId,
            SenderRole = senderRole,
            Body = messageBody,
            LiveCardRef = liveCardRef,
            ServerUtc = DateTimeOffset.UtcNow
        });
    }
}
