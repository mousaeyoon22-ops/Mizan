using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Mizan.Api.Security;
using Mizan.Application.Workspace;
using Mizan.Domain.Workspace;
using Mizan.Infrastructure.Security;

namespace Mizan.Api.Controllers;

[ApiController]
[Authorize]
[Route("api/v1/workspace")]
public sealed class WorkspacePreferencesController : ControllerBase
{
    private readonly WorkspaceModeResolverService _resolver;
    private readonly TenantContext _tenant;

    public WorkspacePreferencesController(WorkspaceModeResolverService resolver, TenantContext tenant)
    {
        _resolver = resolver;
        _tenant = tenant;
    }

    public sealed record ResolveModeRequest(
        WorkspaceExperienceMode RequestedMode,
        bool MotorLargeTargets = false,
        bool CognitiveSimplified = false,
        bool HideEmptyPrintRows = true
    );

    [HttpPost("resolve-profile")]
    [RequireFeature(WorkspaceFeatureKeys.WorkspaceExperienceModes)]
    public IActionResult ResolveEffectiveWorkspace([FromBody] ResolveModeRequest req)
    {
        var profile = _resolver.Resolve(
            userRole: _tenant.Role,
            requestedMode: req.RequestedMode,
            orgPolicy: null,
            motorLargeTargets: req.MotorLargeTargets,
            cognitiveSimplified: req.CognitiveSimplified,
            hideEmptyPrintRows: req.HideEmptyPrintRows);

        return Ok(profile);
    }
}
