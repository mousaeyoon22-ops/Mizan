using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Mizan.Api.Security;
using Mizan.Application.Accessibility;
using Mizan.Domain.Accessibility;
using Mizan.Infrastructure.Security;

namespace Mizan.Api.Controllers;

[ApiController]
[Authorize]
[Route("api/v1/accessibility")]
public sealed class VoiceAndAccessibilityController : ControllerBase
{
    private readonly VoiceCommandGovernanceService _voiceService;
    private readonly TenantContext _tenant;

    public VoiceAndAccessibilityController(VoiceCommandGovernanceService voiceService, TenantContext tenant)
    {
        _voiceService = voiceService;
        _tenant = tenant;
    }

    public sealed record VoiceTranscriptRequest(string IdempotencyKey, string Transcript, string Lang = "ar", decimal HighValueThreshold = 500m);

    [HttpPost("/api/v1/voice/commands")]
    [RequireFeature(AccessibilityFeatureKeys.VoiceCommandOperations)]
    public IActionResult ProcessVoiceCommand([FromBody] VoiceTranscriptRequest req)
    {
        var profile = new UserAccessibilityProfile
        {
            UserId = _tenant.UserId,
            VoiceCommandsEnabled = true,
            VoiceLang = req.Lang,
            VoiceHighValueThreshold = req.HighValueThreshold
        };

        var rec = _voiceService.ProcessTranscript(_tenant.ActiveOrgId, _tenant.UserId, req.IdempotencyKey, req.Transcript, req.Lang, profile);
        return Ok(new
        {
            commandId = rec.Id,
            intent = rec.Intent.ToString(),
            state = rec.State.ToString(),
            isFinancialMutation = rec.IsFinancialMutation,
            amount = rec.AmountValue,
            currency = rec.Currency,
            readBackAr = rec.ReadBackPromptAr,
            readBackEn = rec.ReadBackPromptEn,
            transcriptSha256 = rec.TranscriptSha256
        });
    }

    public sealed record ConfirmVoiceRequest(VoiceConfirmationMethod Method, Guid PostedJournalId, decimal HighValueThreshold = 500m);

    [HttpPost("/api/v1/voice/commands/{commandId:guid}/confirm")]
    [RequireFeature(AccessibilityFeatureKeys.VoiceCommandOperations)]
    public IActionResult ConfirmVoiceDraft(Guid commandId, [FromBody] ConfirmVoiceRequest req)
    {
        var profile = new UserAccessibilityProfile { UserId = _tenant.UserId, VoiceHighValueThreshold = req.HighValueThreshold };
        var rec = _voiceService.ConfirmDraft(_tenant.ActiveOrgId, _tenant.UserId, commandId, req.Method, profile, req.PostedJournalId);
        return Ok(new { commandId = rec.Id, state = rec.State.ToString(), confirmedAt = rec.ConfirmedAt });
    }
}
