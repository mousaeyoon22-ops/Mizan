using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Mizan.Infrastructure.Persistence;
using Mizan.Infrastructure.Security;

namespace Mizan.Api.Controllers;

/// <summary>City-Pilot Operational Endpoints: Meter Reading Reconciliation & Tank/Equipment Custody Logs.</summary>
[ApiController]
[Authorize]
[Route("api/v1/pilot")]
public sealed class CityPilotOpsController : ControllerBase
{
    private readonly MizanDbContext _db;
    private readonly TenantContext _tenant;

    public CityPilotOpsController(MizanDbContext db, TenantContext tenant)
    {
        _db = db;
        _tenant = tenant;
    }

    public sealed record MeterReadingRequest(string IdempotencyKey, string MeterName, DateOnly ReadingDate, decimal OpeningReading, decimal ClosingReading, decimal ReconciledSalesQty, string UnitLabel = "LITER");

    [HttpPost("meters")]
    public async Task<IActionResult> RecordMeterReading([FromBody] MeterReadingRequest req, CancellationToken ct)
    {
        if (req.ClosingReading < req.OpeningReading)
            return BadRequest(new { error = "CLOSING_READING_CANNOT_BE_LESS_THAN_OPENING" });

        var id = Guid.NewGuid();
        var conn = _db.Database.GetDbConnection();
        if (conn.State != System.Data.ConnectionState.Open) await conn.OpenAsync(ct);

        await using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
            INSERT INTO meter_readings (id, org_id, idempotency_key, meter_name, reading_date, opening_reading, closing_reading, unit_label, reconciled_sales_qty, recorded_by)
            VALUES (@id, @org, @idem, @name, @dt, @op, @cl, @unit, @sales, @usr)
            ON CONFLICT (org_id, idempotency_key) DO NOTHING;";
        AddParam(cmd, "@id", id);
        AddParam(cmd, "@org", _tenant.ActiveOrgId);
        AddParam(cmd, "@idem", req.IdempotencyKey);
        AddParam(cmd, "@name", req.MeterName.Trim());
        AddParam(cmd, "@dt", req.ReadingDate);
        AddParam(cmd, "@op", req.OpeningReading);
        AddParam(cmd, "@cl", req.ClosingReading);
        AddParam(cmd, "@unit", req.UnitLabel.Trim());
        AddParam(cmd, "@sales", req.ReconciledSalesQty);
        AddParam(cmd, "@usr", _tenant.UserId);
        var affected = await cmd.ExecuteNonQueryAsync(ct);

        var delta = Math.Round(req.ClosingReading - req.OpeningReading, 4);
        var variance = Math.Round(delta - req.ReconciledSalesQty, 4);
        return Created(string.Empty, new { id, status = affected == 1 ? "POSTED" : "IDEMPOTENT_REPLAY", delta, variance });
    }

    public sealed record CustodyLogRequest(string IdempotencyKey, string HolderType, string HolderName, string EquipmentSku, decimal QtyOut, decimal QtyReturned, string? Notes);

    [HttpPost("custody")]
    public async Task<IActionResult> RecordEquipmentCustody([FromBody] CustodyLogRequest req, CancellationToken ct)
    {
        var id = Guid.NewGuid();
        var conn = _db.Database.GetDbConnection();
        if (conn.State != System.Data.ConnectionState.Open) await conn.OpenAsync(ct);

        await using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
            INSERT INTO equipment_custody_logs (id, org_id, idempotency_key, holder_type, holder_name, equipment_sku, qty_out, qty_returned, notes, recorded_by)
            VALUES (@id, @org, @idem, @htype, @hname, @sku, @qout, @qret, @notes, @usr)
            ON CONFLICT (org_id, idempotency_key) DO NOTHING;";
        AddParam(cmd, "@id", id);
        AddParam(cmd, "@org", _tenant.ActiveOrgId);
        AddParam(cmd, "@idem", req.IdempotencyKey);
        AddParam(cmd, "@htype", req.HolderType.Trim().ToUpperInvariant());
        AddParam(cmd, "@hname", req.HolderName.Trim());
        AddParam(cmd, "@sku", req.EquipmentSku.Trim());
        AddParam(cmd, "@qout", req.QtyOut);
        AddParam(cmd, "@qret", req.QtyReturned);
        AddParam(cmd, "@notes", (object?)req.Notes ?? DBNull.Value);
        AddParam(cmd, "@usr", _tenant.UserId);
        var affected = await cmd.ExecuteNonQueryAsync(ct);

        return Created(string.Empty, new { id, status = affected == 1 ? "POSTED" : "IDEMPOTENT_REPLAY" });
    }

    private static void AddParam(System.Data.Common.DbCommand cmd, string name, object val)
    {
        var p = cmd.CreateParameter();
        p.ParameterName = name;
        p.Value = val;
        cmd.Parameters.Add(p);
    }
}
