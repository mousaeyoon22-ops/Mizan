using System.Security.Cryptography;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Mizan.Infrastructure.Persistence;
using Mizan.Infrastructure.Security;

namespace Mizan.Api.Controllers;

/// <summary>
/// Fixes DEF-301 (P0): Organization Onboarding, Default Chart-of-Accounts Bootstrap & Member Role Management.
/// </summary>
[ApiController]
[Authorize]
[Route("api/v1/organizations")]
public sealed class OrganizationsController : ControllerBase
{
    private readonly MizanDbContext _db;
    private readonly TenantContext _tenant;

    public OrganizationsController(MizanDbContext db, TenantContext tenant)
    {
        _db = db;
        _tenant = tenant;
    }

    public sealed record CreateOrgRequest(string TradeName, string Sector, string BaseCurrency = "USD", string InventoryMethod = "FIFO", string VisibilityMode = "QR_ONLY");

    [HttpPost]
    public async Task<IActionResult> CreateOrganization([FromBody] CreateOrgRequest req, CancellationToken ct)
    {
        var orgId = Guid.NewGuid();
        var uidCode = $"ORG-{RandomNumberGenerator.GetInt32(100000, 999999)}";
        var currency = req.BaseCurrency.Trim().ToUpperInvariant();

        await using var tx = await _db.Database.BeginTransactionAsync(ct);
        var conn = _db.Database.GetDbConnection();

        await using (var cmd = conn.CreateCommand())
        {
            cmd.CommandText = @"
                INSERT INTO organizations (id, owner_user_id, uid_code, trade_name, sector, visibility_mode, base_currency, inventory_method)
                VALUES (@id, @owner, @uid, @name, @sector, @vis, @curr, @inv);
                INSERT INTO organization_members (org_id, user_id, role) VALUES (@id, @owner, 'OWNER');
                SELECT set_config('app.current_org_id', @id::text, true);";
            AddParam(cmd, "@id", orgId);
            AddParam(cmd, "@owner", _tenant.UserId);
            AddParam(cmd, "@uid", uidCode);
            AddParam(cmd, "@name", req.TradeName.Trim());
            AddParam(cmd, "@sector", req.Sector.Trim());
            AddParam(cmd, "@vis", req.VisibilityMode.Trim().ToUpperInvariant());
            AddParam(cmd, "@curr", currency);
            AddParam(cmd, "@inv", req.InventoryMethod.Trim().ToUpperInvariant());
            await cmd.ExecuteNonQueryAsync(ct);
        }

        // Bootstrap standard Chart of Accounts automatically
        await using (var coa = conn.CreateCommand())
        {
            coa.CommandText = @"
                INSERT INTO accounts (org_id, code, name, account_type, currency) VALUES
                (@org, '1110', 'Main Cash Box / الصندوق الرئيسي', 'ASSET', @curr),
                (@org, '1120', 'Accounts Receivable / الذمم المدينة', 'ASSET', @curr),
                (@org, '1130', 'Inventory / المخزون', 'ASSET', @curr),
                (@org, '2110', 'Accounts Payable / الذمم الدائنة', 'LIABILITY', @curr),
                (@org, '2130', 'Customer Advances (IFRS 15) / دفعات مقدمة', 'LIABILITY', @curr),
                (@org, '4110', 'Sales Revenue / إيراد المبيعات', 'REVENUE', @curr),
                (@org, '4120', 'FX Gain / أرباح فروقات الصرف', 'REVENUE', @curr),
                (@org, '5110', 'COGS (IAS 2) / تكلفة المبيعات', 'EXPENSE', @curr),
                (@org, '5210', 'Operating Expenses / مصروفات التشغيل', 'EXPENSE', @curr),
                (@org, '5220', 'FX Loss / خسائر فروقات الصرف', 'EXPENSE', @curr);";
            AddParam(coa, "@org", orgId);
            AddParam(coa, "@curr", currency);
            await coa.ExecuteNonQueryAsync(ct);
        }

        await tx.CommitAsync(ct);
        return Created(string.Empty, new { orgId, uidCode, tradeName = req.TradeName.Trim(), currency, defaultAccountsSeeded = 10 });
    }

    private static void AddParam(System.Data.Common.DbCommand cmd, string name, object val)
    {
        var p = cmd.CreateParameter();
        p.ParameterName = name;
        p.Value = val;
        cmd.Parameters.Add(p);
    }
}
