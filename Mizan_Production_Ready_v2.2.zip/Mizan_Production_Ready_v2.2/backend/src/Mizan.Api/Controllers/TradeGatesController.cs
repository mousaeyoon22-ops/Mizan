using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Mizan.Api.Security;
using Mizan.Application.Services;
using Mizan.Domain.Entities;
using Mizan.Domain.Features;
using Mizan.Infrastructure.Persistence;
using Mizan.Infrastructure.Security;

namespace Mizan.Api.Controllers;

/// <summary>Fixes DEF-405: Full 3-Decision Trade Gate REST Controller backed by MizanDbContext.</summary>
[ApiController]
[Authorize]
[Route("api/v1/gates")]
public sealed class TradeGatesController : ControllerBase
{
    private readonly TradeGateService _gateService;
    private readonly MizanDbContext _db;
    private readonly TenantContext _tenant;

    public TradeGatesController(TradeGateService gateService, MizanDbContext db, TenantContext tenant)
    {
        _gateService = gateService;
        _db = db;
        _tenant = tenant;
    }

    public sealed record DispatchGateDocRequest(string IdempotencyKey, string DocType, string UblPayloadJson);

    [HttpPost("{gateId:guid}/documents")]
    [RequireFeature(MizanFeatureKeys.TradeGatesExchange)]
    public async Task<IActionResult> DispatchDocument(Guid gateId, [FromBody] DispatchGateDocRequest req, CancellationToken ct)
    {
        var gate = await _db.TradeGates.FirstOrDefaultAsync(g => g.Id == gateId, ct);
        if (gate is null) return NotFound(new { error = "TRADE_GATE_NOT_FOUND" });

        var pairing = await _db.Pairings.FirstOrDefaultAsync(p => p.Id == gate.PairingId, ct);
        if (pairing is null) return NotFound(new { error = "PAIRING_NOT_FOUND" });

        var doc = _gateService.SendDocument(pairing, gate, _tenant.ActiveOrgId, req.IdempotencyKey, req.DocType, req.UblPayloadJson);
        await _db.GateDocuments.AddAsync(doc, ct);
        await _db.SaveChangesAsync(ct);

        return Created(string.Empty, new { documentId = doc.Id, state = doc.State.ToString(), payloadSha256 = doc.PayloadSha256 });
    }

    [HttpPost("{gateId:guid}/documents/{documentId:guid}/approve")]
    [RequireFeature(MizanFeatureKeys.TradeGatesExchange)]
    public async Task<IActionResult> ApproveDocument(Guid gateId, Guid documentId, CancellationToken ct)
    {
        var gate = await _db.TradeGates.FirstOrDefaultAsync(g => g.Id == gateId, ct);
        var doc = await _db.GateDocuments.FirstOrDefaultAsync(d => d.Id == documentId && d.GateId == gateId, ct);
        if (gate is null || doc is null) return NotFound(new { error = "GATE_OR_DOCUMENT_NOT_FOUND" });

        _gateService.ApproveDocument(gate, doc, _tenant.ActiveOrgId);
        doc.UpdatedAt = DateTimeOffset.UtcNow;
        await _db.SaveChangesAsync(ct);

        return Ok(new { documentId = doc.Id, state = doc.State.ToString() });
    }

    [HttpPost("ubl-preview")]
    public IActionResult GenerateUbl21Preview([FromQuery] string invoiceId, [FromQuery] string currency, [FromQuery] decimal net, [FromQuery] decimal tax)
    {
        var ubl = Ubl21DocumentMapper.SerializeUbl21Invoice(invoiceId, DateTimeOffset.UtcNow, currency, "UID-SUPPLIER", "UID-CUSTOMER", net, tax);
        return Content(ubl, "application/json");
    }
}
