using System.Security.Cryptography;
using System.Text;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Mizan.Application.Security;
using Mizan.Infrastructure.Persistence;

namespace Mizan.Api.Controllers;

/// <summary>
/// Fixes DEF-404: Complete Register, Login, Atomic Refresh Token Rotation (with reuse detection) & Logout.
/// </summary>
[ApiController]
[Route("api/v1/auth")]
public sealed class AuthController : ControllerBase
{
    private readonly MizanDbContext _db;
    private readonly PasswordAndTokenService _auth;
    private readonly IConfiguration _config;

    public AuthController(MizanDbContext db, PasswordAndTokenService auth, IConfiguration config)
    {
        _db = db;
        _auth = auth;
        _config = config;
    }

    public sealed record RegisterRequest(string Email, string Phone, string Password, string PreferredLang = "ar", string BaseCurrency = "USD");
    public sealed record LoginRequest(string EmailOrPhone, string Password, string? DeviceLabel);
    public sealed record RefreshRequest(string RefreshToken, string? DeviceLabel);

    [HttpPost("register")]
    [AllowAnonymous]
    public async Task<IActionResult> Register([FromBody] RegisterRequest req, CancellationToken ct)
    {
        var userId = Guid.NewGuid();
        var uidCode = $"USR-{RandomNumberGenerator.GetInt32(100000, 999999)}";
        var hash = _auth.HashPassword(req.Password);

        await using var cmd = _db.Database.GetDbConnection().CreateCommand();
        if (cmd.Connection!.State != System.Data.ConnectionState.Open) await cmd.Connection.OpenAsync(ct);

        cmd.CommandText = @"
            INSERT INTO users (id, uid_code, email, phone, password_hash, kyc_level, preferred_lang, base_currency)
            VALUES (@id, @uid, @email, @phone, @hash, 1, @lang, @curr);";
        AddParam(cmd, "@id", userId);
        AddParam(cmd, "@uid", uidCode);
        AddParam(cmd, "@email", req.Email.Trim().ToLowerInvariant());
        AddParam(cmd, "@phone", req.Phone.Trim());
        AddParam(cmd, "@hash", hash);
        AddParam(cmd, "@lang", req.PreferredLang.Trim().ToLowerInvariant());
        AddParam(cmd, "@curr", req.BaseCurrency.Trim().ToUpperInvariant());
        await cmd.ExecuteNonQueryAsync(ct);

        return Created(string.Empty, new { userId, uidCode, email = req.Email.Trim().ToLowerInvariant(), kycLevel = 1 });
    }

    [HttpPost("login")]
    [AllowAnonymous]
    public async Task<IActionResult> Login([FromBody] LoginRequest req, CancellationToken ct)
    {
        await using var cmd = _db.Database.GetDbConnection().CreateCommand();
        if (cmd.Connection!.State != System.Data.ConnectionState.Open) await cmd.Connection.OpenAsync(ct);

        cmd.CommandText = "SELECT id, uid_code, email, password_hash FROM users WHERE email = @id OR phone = @id LIMIT 1;";
        AddParam(cmd, "@id", req.EmailOrPhone.Trim().ToLowerInvariant());

        await using var reader = await cmd.ExecuteReaderAsync(ct);
        if (!await reader.ReadAsync(ct))
            return Unauthorized(new { error = "INVALID_CREDENTIALS" });

        var userId = reader.GetGuid(0);
        var uidCode = reader.GetString(1);
        var email = reader.GetString(2);
        var storedHash = reader.GetString(3);
        await reader.CloseAsync();

        if (!_auth.VerifyPassword(req.Password, storedHash))
            return Unauthorized(new { error = "INVALID_CREDENTIALS" });

        var (accessToken, exp) = IssueAccess(userId, uidCode, email);
        var (rawRefresh, refreshSha) = _auth.IssueRefreshToken();

        await using var ins = _db.Database.GetDbConnection().CreateCommand();
        ins.CommandText = "INSERT INTO refresh_tokens (user_id, token_sha256, device_label, expires_at) VALUES (@u, @h, @d, @e);";
        AddParam(ins, "@u", userId);
        AddParam(ins, "@h", refreshSha);
        AddParam(ins, "@d", req.DeviceLabel ?? "unknown-device");
        AddParam(ins, "@e", DateTimeOffset.UtcNow.AddDays(30));
        await ins.ExecuteNonQueryAsync(ct);

        return Ok(new { userId, uidCode, accessToken, expiresAtUtc = exp, refreshToken = rawRefresh });
    }

    [HttpPost("refresh")]
    [AllowAnonymous]
    public async Task<IActionResult> Refresh([FromBody] RefreshRequest req, CancellationToken ct)
    {
        var oldSha = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(req.RefreshToken))).ToLowerInvariant();
        await using var tx = await _db.Database.BeginTransactionAsync(ct);
        var conn = _db.Database.GetDbConnection();

        Guid oldId, userId;
        string uidCode, email;
        DateTimeOffset expiresAt;
        bool isRevoked;

        await using (var q = conn.CreateCommand())
        {
            q.CommandText = @"
                SELECT rt.id, rt.user_id, rt.expires_at, (rt.revoked_at IS NOT NULL), u.uid_code, u.email
                FROM refresh_tokens rt
                JOIN users u ON u.id = rt.user_id
                WHERE rt.token_sha256 = @h LIMIT 1;";
            AddParam(q, "@h", oldSha);
            await using var r = await q.ExecuteReaderAsync(ct);
            if (!await r.ReadAsync(ct))
                return Unauthorized(new { error = "INVALID_REFRESH_TOKEN" });
            oldId = r.GetGuid(0);
            userId = r.GetGuid(1);
            expiresAt = r.GetFieldValue<DateTimeOffset>(2);
            isRevoked = r.GetBoolean(3);
            uidCode = r.GetString(4);
            email = r.GetString(5);
        }

        if (isRevoked || expiresAt <= DateTimeOffset.UtcNow)
        {
            // Reuse detection: revoke all active sessions for this user if a revoked token is replayed
            if (isRevoked)
            {
                await using var revAll = conn.CreateCommand();
                revAll.CommandText = "UPDATE refresh_tokens SET revoked_at = NOW() WHERE user_id = @u AND revoked_at IS NULL;";
                AddParam(revAll, "@u", userId);
                await revAll.ExecuteNonQueryAsync(ct);
                await tx.CommitAsync(ct);
            }
            return Unauthorized(new { error = isRevoked ? "REFRESH_TOKEN_REUSE_DETECTED" : "REFRESH_TOKEN_EXPIRED" });
        }

        var newId = Guid.NewGuid();
        var (newRaw, newSha) = _auth.IssueRefreshToken();
        await using (var rot = conn.CreateCommand())
        {
            rot.CommandText = @"
                INSERT INTO refresh_tokens (id, user_id, token_sha256, device_label, expires_at) VALUES (@nid, @u, @nh, @d, @e);
                UPDATE refresh_tokens SET revoked_at = NOW(), replaced_by_id = @nid WHERE id = @oid;";
            AddParam(rot, "@nid", newId);
            AddParam(rot, "@u", userId);
            AddParam(rot, "@nh", newSha);
            AddParam(rot, "@d", req.DeviceLabel ?? "rotated-device");
            AddParam(rot, "@e", DateTimeOffset.UtcNow.AddDays(30));
            AddParam(rot, "@oid", oldId);
            await rot.ExecuteNonQueryAsync(ct);
        }

        await tx.CommitAsync(ct);
        var (accessToken, exp) = IssueAccess(userId, uidCode, email);
        return Ok(new { userId, uidCode, accessToken, expiresAtUtc = exp, refreshToken = newRaw });
    }

    [HttpPost("logout")]
    [Authorize]
    public async Task<IActionResult> Logout([FromBody] RefreshRequest req, CancellationToken ct)
    {
        var sha = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(req.RefreshToken))).ToLowerInvariant();
        await using var cmd = _db.Database.GetDbConnection().CreateCommand();
        if (cmd.Connection!.State != System.Data.ConnectionState.Open) await cmd.Connection.OpenAsync(ct);
        cmd.CommandText = "UPDATE refresh_tokens SET revoked_at = NOW() WHERE token_sha256 = @h AND revoked_at IS NULL;";
        AddParam(cmd, "@h", sha);
        await cmd.ExecuteNonQueryAsync(ct);
        return Ok(new { revoked = true });
    }

    private (string AccessToken, DateTimeOffset ExpiresAtUtc) IssueAccess(Guid userId, string uidCode, string email)
        => _auth.IssueJwtAccessToken(userId, uidCode, email, _config["JWT_SIGNING_KEY"]!, _config["JWT_ISSUER"] ?? "mizan.auth", _config["JWT_AUDIENCE"] ?? "mizan.api");

    private static void AddParam(System.Data.Common.DbCommand cmd, string name, object val)
    {
        var p = cmd.CreateParameter();
        p.ParameterName = name;
        p.Value = val;
        cmd.Parameters.Add(p);
    }
}
