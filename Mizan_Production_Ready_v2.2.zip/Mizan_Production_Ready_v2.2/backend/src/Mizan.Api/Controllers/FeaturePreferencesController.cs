using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Mizan.Application.Features;
using Mizan.Infrastructure.Security;

namespace Mizan.Api.Controllers;

/// <summary>Fixes DEF-404: Strictly binds to validated `_tenant.ActiveOrgId` instead of raw request header.</summary>
[ApiController]
[Authorize]
[Route("api/v1/preferences/features")]
public sealed class FeaturePreferencesController : ControllerBase
{
    private readonly FeatureGovernanceService _governance;
    private readonly TenantContext _tenant;

    public FeaturePreferencesController(FeatureGovernanceService governance, TenantContext tenant)
    {
        _governance = governance;
        _tenant = tenant;
    }

    [HttpGet]
    public IActionResult GetEffectiveFeatures()
        => Ok(_governance.GetEffectiveMatrix(_tenant.ActiveOrgId));

    public sealed record ToggleRequest(bool Enabled);

    [HttpPut("{featureKey}")]
    public IActionResult ToggleOrganizationFeature(string featureKey, [FromBody] ToggleRequest req)
    {
        if (_tenant.Role != "OWNER")
            return StatusCode(403, new { error = "ONLY_ORG_OWNER_CAN_TOGGLE_FEATURES" });

        try
        {
            _governance.SetOrganizationPreference(_tenant.ActiveOrgId, featureKey, req.Enabled);
            return Ok(new { orgId = _tenant.ActiveOrgId, featureKey, effectiveEnabled = _governance.IsEnabled(_tenant.ActiveOrgId, featureKey) });
        }
        catch (InvalidOperationException ex)
        {
            return StatusCode(403, new { error = ex.Message });
        }
    }
}
