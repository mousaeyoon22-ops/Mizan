using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Mizan.Api.Security;
using Mizan.Application.FX;
using Mizan.Application.Persistence;
using Mizan.Application.Translation;
using Mizan.Domain.Entities;
using Mizan.Domain.Features;
using Mizan.Infrastructure.Security;

namespace Mizan.Api.Controllers;

/// <summary>Fixes DEF-404: Uses validated `_tenant.ActiveOrgId` & persists balanced FX voucher journal entries to PostgreSQL.</summary>
[ApiController]
[Authorize]
[Route("api/v1/fx")]
public sealed class FxAndTranslationController : ControllerBase
{
    private readonly Ias21FxAccountingEngine _fxEngine;
    private readonly InstantTranslationService _translator;
    private readonly ILedgerRepository _ledgerRepo;
    private readonly TenantContext _tenant;

    public FxAndTranslationController(
        Ias21FxAccountingEngine fxEngine,
        InstantTranslationService translator,
        ILedgerRepository ledgerRepo,
        TenantContext tenant)
    {
        _fxEngine = fxEngine;
        _translator = translator;
        _ledgerRepo = ledgerRepo;
        _tenant = tenant;
    }

    public sealed record ExchangeVoucherRequest(
        string IdempotencyKey,
        string BaseCurrency,
        Guid SourceCashAccId, string SourceCurrency, decimal SourceAmount, decimal SourceBookRateToBase,
        Guid TargetCashAccId, string TargetCurrency, decimal TargetAmount, decimal TargetBookRateToBase,
        Guid FxGainAccId, Guid FxLossAccId
    );

    [HttpPost("exchange-vouchers")]
    [RequireFeature(MizanFeatureKeys.DirectCurrencyExchangeVoucher)]
    public async Task<IActionResult> CreateExchangeVoucher([FromBody] ExchangeVoucherRequest req, CancellationToken ct)
    {
        var orgId = _tenant.ActiveOrgId;
        var existing = await _ledgerRepo.FindByIdempotencyKeyAsync(orgId, req.IdempotencyKey, ct);
        if (existing is not null)
            return Ok(new { status = "IDEMPOTENT_REPLAY", entryId = existing.Id });

        var res = _fxEngine.ExecuteDirectCurrencyExchange(
            orgId, req.IdempotencyKey, Guid.NewGuid(), req.BaseCurrency,
            req.SourceCashAccId, req.SourceCurrency, req.SourceAmount, req.SourceBookRateToBase,
            req.TargetCashAccId, req.TargetCurrency, req.TargetAmount, req.TargetBookRateToBase,
            req.FxGainAccId, req.FxLossAccId);

        // Persist balanced base-currency mirror entry durably via ILedgerRepository
        var dbEntry = new JournalEntry
        {
            OrgId = orgId,
            IdempotencyKey = req.IdempotencyKey,
            ReferenceType = "FX_EXCHANGE_VOUCHER",
            ReferenceId = res.Entry.ReferenceId,
            Description = res.Entry.Description,
            Currency = req.BaseCurrency,
            ExchangeRate = 1.0m,
            CreatedBy = _tenant.UserId
        };
        foreach (var l in res.Entry.Lines)
        {
            dbEntry.AddLine(new JournalLine
            {
                OrgId = orgId,
                AccountId = l.AccountId,
                Debit = l.BaseDebit,
                Credit = l.BaseCredit,
                BaseDebit = l.BaseDebit,
                BaseCredit = l.BaseCredit
            });
        }
        await _ledgerRepo.SaveJournalEntryAsync(dbEntry, ct);

        return Created(string.Empty, new
        {
            entryId = dbEntry.Id,
            fxDiffBaseAmount = res.FxDiffBaseAmount,
            classification = res.FxDiffBaseAmount > 0 ? "FX_GAIN" : (res.FxDiffBaseAmount < 0 ? "FX_LOSS_EXPENSE" : "PAR"),
            baseCurrency = res.BaseCurrency
        });
    }

    public sealed record TranslateFieldRequest(string Text, string SourceLang, string TargetLang);

    [HttpPost("/api/v1/translation/field")]
    [RequireFeature(MizanFeatureKeys.InstantCrossBorderTranslation)]
    public async Task<IActionResult> TranslateField([FromBody] TranslateFieldRequest req, CancellationToken ct)
    {
        try
        {
            var result = await _translator.TranslateFieldAsync(_tenant.ActiveOrgId, req.Text, req.SourceLang, req.TargetLang, ct);
            return Ok(result);
        }
        catch (InvalidOperationException ex)
        {
            return StatusCode(403, new { error = ex.Message });
        }
    }
}
