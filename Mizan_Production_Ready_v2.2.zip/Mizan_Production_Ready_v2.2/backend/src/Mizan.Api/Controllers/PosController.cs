using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Mizan.Api.Security;
using Mizan.Application.POS;
using Mizan.Domain.POS;
using Mizan.Infrastructure.Persistence;
using Mizan.Infrastructure.Security;

namespace Mizan.Api.Controllers;

/// <summary>
/// Fixes DEF-305: Real database lookup in LookupVariantByBarcode & persistent shift open/close via MizanDbContext.
/// </summary>
[ApiController]
[Authorize]
[Route("api/v1/pos")]
public sealed class PosController : ControllerBase
{
    private readonly PosShiftAndZReportService _posService;
    private readonly MizanDbContext _db;
    private readonly TenantContext _tenant;

    public PosController(PosShiftAndZReportService posService, MizanDbContext db, TenantContext tenant)
    {
        _posService = posService;
        _db = db;
        _tenant = tenant;
    }

    public sealed record OpenShiftRequest(Guid TerminalId, decimal OpeningFloat, string Currency);

    [HttpPost("shifts/open")]
    [RequireFeature(PosFeatureKeys.PosShiftsAndZReport)]
    public async Task<IActionResult> OpenShift([FromBody] OpenShiftRequest req, CancellationToken ct)
    {
        if (_tenant.Role is not ("OWNER" or "CASHIER" or "ACCOUNTANT"))
            return StatusCode(403, new { error = "ROLE_NOT_AUTHORIZED_FOR_POS_SHIFT" });

        var shift = _posService.OpenShift(_tenant.ActiveOrgId, req.TerminalId, _tenant.UserId, req.OpeningFloat, req.Currency);
        await _db.PosShifts.AddAsync(shift, ct);
        await _db.SaveChangesAsync(ct);
        return Created(string.Empty, new { shiftId = shift.Id, status = shift.Status.ToString(), openedAt = shift.OpenedAt });
    }

    [HttpGet("variants/lookup/{barcode}")]
    [RequireFeature(PosFeatureKeys.ItemVariantsMatrix)]
    public async Task<IActionResult> LookupVariantByBarcode(string barcode, CancellationToken ct)
    {
        var variant = await _db.ItemVariants
            .AsNoTracking()
            .FirstOrDefaultAsync(v => v.OrgId == _tenant.ActiveOrgId && v.VariantBarcode == barcode.Trim(), ct);

        if (variant is null)
            return NotFound(new { error = "VARIANT_BARCODE_NOT_FOUND", barcode });

        return Ok(new
        {
            variant.Id,
            variant.ParentItemId,
            variant.VariantSku,
            variant.VariantBarcode,
            variant.SizeLabel,
            variant.ColorLabel,
            variant.ColorHex,
            variant.SalePrice,
            variant.Currency,
            variant.QtyOnHand,
            variant.RowVersion
        });
    }
}
