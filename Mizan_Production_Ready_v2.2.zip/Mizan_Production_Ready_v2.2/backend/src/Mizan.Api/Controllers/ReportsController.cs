using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Mizan.Application.Reports;

namespace Mizan.Api.Controllers;

[ApiController]
[Authorize]
[Route("api/v1/reports")]
public sealed class ReportsController : ControllerBase
{
    private readonly A4CleanReportBuilder _builder;

    public ReportsController(A4CleanReportBuilder builder) => _builder = builder;

    public sealed record DailyA4ReportRequest(
        string OrgName,
        DateOnly ReportDate,
        string Currency,
        List<DailySalesRow> Sales,
        List<DailyExpenseRow> Expenses,
        List<MeterReadingRow> Meters,
        List<CustomerBalanceRow> Balances,
        decimal TrialBalanceVariance = 0m,
        bool HideEmptyRows = true,
        bool IsArabic = true
    );

    [HttpPost("daily-a4/html")]
    public IActionResult RenderDailyA4Html([FromBody] DailyA4ReportRequest req)
    {
        var clean = _builder.BuildCleanModel(
            req.OrgName, req.ReportDate, req.Currency,
            req.Sales, req.Expenses, req.Meters, req.Balances,
            req.TrialBalanceVariance, req.HideEmptyRows);

        var html = _builder.RenderA4Html(clean, req.IsArabic);
        return Content(html, "text/html; charset=utf-8");
    }
}
