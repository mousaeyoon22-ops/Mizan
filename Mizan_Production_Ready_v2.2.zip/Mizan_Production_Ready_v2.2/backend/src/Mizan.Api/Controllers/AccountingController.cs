using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Mizan.Application.Persistence;
using Mizan.Application.Services;
using Mizan.Domain.Entities;
using Mizan.Infrastructure.Persistence;
using Mizan.Infrastructure.Security;

namespace Mizan.Api.Controllers;

/// <summary>
/// Fixes DEF-403 (P0): Sets `CreatedBy = _tenant.UserId` and durably persists/loads `FifoLayers` in PostgreSQL.
/// </summary>
[ApiController]
[Authorize]
[Route("api/v1/ledger")]
public sealed class AccountingController : ControllerBase
{
    private readonly DoubleEntryAccountingEngine _engine;
    private readonly ILedgerRepository _repo;
    private readonly MizanDbContext _db;
    private readonly TenantContext _tenant;

    public AccountingController(DoubleEntryAccountingEngine engine, ILedgerRepository repo, MizanDbContext db, TenantContext tenant)
    {
        _engine = engine;
        _repo = repo;
        _db = db;
        _tenant = tenant;
    }

    [HttpGet("trial-balance/variance")]
    public async Task<IActionResult> GetTrialBalanceVariance(CancellationToken ct)
    {
        var orgId = _tenant.ActiveOrgId;
        var variance = await _repo.GetTrialBalanceVarianceAsync(orgId, ct);
        return Ok(new { orgId, variance, balanced = variance == 0.0000m });
    }

    public sealed record AdvancePaymentRequest(
        string IdempotencyKey, Guid OrderId, decimal Amount,
        Guid CashAccId, Guid CustomerAdvanceAccId, Guid? CustomerOrgId, string Currency);

    [HttpPost("advances")]
    public async Task<IActionResult> RecordCustomerAdvance([FromBody] AdvancePaymentRequest req, CancellationToken ct)
    {
        var orgId = _tenant.ActiveOrgId;
        var existing = await _repo.FindByIdempotencyKeyAsync(orgId, req.IdempotencyKey, ct);
        if (existing is not null)
            return Ok(new { status = "IDEMPOTENT_REPLAY", entryId = existing.Id });

        var entry = _engine.RecordCustomerAdvancePayment(
            orgId, req.IdempotencyKey, req.OrderId, req.Amount,
            req.CashAccId, req.CustomerAdvanceAccId, req.CustomerOrgId, req.Currency, _tenant.UserId);

        await _repo.SaveJournalEntryAsync(entry, ct);
        return Created(string.Empty, new { status = "POSTED", entryId = entry.Id });
    }

    public sealed record PurchaseReceiptRequest(
        string IdempotencyKey, Guid PurchaseDocId, Guid ItemId,
        decimal Qty, decimal UnitCost, Guid InventoryAccId, Guid PayableOrCashAccId, Guid? SupplierOrgId, string Currency);

    [HttpPost("purchases")]
    public async Task<IActionResult> RecordInventoryPurchase([FromBody] PurchaseReceiptRequest req, CancellationToken ct)
    {
        var orgId = _tenant.ActiveOrgId;
        var existing = await _repo.FindByIdempotencyKeyAsync(orgId, req.IdempotencyKey, ct);
        if (existing is not null)
            return Ok(new { status = "IDEMPOTENT_REPLAY", entryId = existing.Id });

        var item = await _db.Items.FirstOrDefaultAsync(i => i.Id == req.ItemId && i.OrgId == orgId, ct);
        if (item is null) return NotFound(new { error = "ITEM_NOT_FOUND" });

        await using var tx = await _db.Database.BeginTransactionAsync(ct);
        var entry = _engine.RecordInventoryPurchase(
            orgId, req.IdempotencyKey, req.PurchaseDocId, item,
            req.Qty, req.UnitCost, req.InventoryAccId, req.PayableOrCashAccId, req.SupplierOrgId, req.Currency, _tenant.UserId);

        var newLayer = _engine.FifoLayers.Last();
        await _db.FifoLayers.AddAsync(newLayer, ct);
        await _repo.SaveJournalEntryAsync(entry, ct);
        await tx.CommitAsync(ct);

        return Created(string.Empty, new { status = "POSTED", entryId = entry.Id, fifoLayerId = newLayer.Id, newQtyOnHand = item.QtyOnHand, weightedAvgCost = item.WeightedAvgCost });
    }

    public sealed record DeliveryRevenueRequest(
        string IdempotencyKey, Guid DeliveryDocId, Guid ItemId,
        decimal QtyDelivered, decimal UnitSalePrice, decimal AdvanceApplied, InventoryValuationMethod ValuationMethod,
        Guid ArAccId, Guid CustomerAdvanceAccId, Guid RevenueAccId, Guid CogsAccId, Guid InventoryAccId,
        Guid? CustomerOrgId, string Currency);

    [HttpPost("deliveries")]
    public async Task<IActionResult> RecordDeliveryAndRecognizeRevenue([FromBody] DeliveryRevenueRequest req, CancellationToken ct)
    {
        var orgId = _tenant.ActiveOrgId;
        var existing = await _repo.FindByIdempotencyKeyAsync(orgId, req.IdempotencyKey, ct);
        if (existing is not null)
            return Ok(new { status = "IDEMPOTENT_REPLAY", entryId = existing.Id });

        var item = await _db.Items.FirstOrDefaultAsync(i => i.Id == req.ItemId && i.OrgId == orgId, ct);
        if (item is null) return NotFound(new { error = "ITEM_NOT_FOUND" });

        await using var tx = await _db.Database.BeginTransactionAsync(ct);
        var activeLayers = await _db.FifoLayers
            .Where(l => l.OrgId == orgId && l.ItemId == item.Id && l.QtyRemaining > 0)
            .OrderBy(l => l.ReceivedAt)
            .ToListAsync(ct);
        _engine.LoadPersistedFifoLayers(activeLayers);

        var (entry, revenue, cogs) = _engine.RecordDeliveryAndRecognizeRevenue(
            orgId, req.IdempotencyKey, req.DeliveryDocId, item,
            req.QtyDelivered, req.UnitSalePrice, req.AdvanceApplied, req.ValuationMethod,
            req.ArAccId, req.CustomerAdvanceAccId, req.RevenueAccId, req.CogsAccId, req.InventoryAccId,
            req.CustomerOrgId, req.Currency, _tenant.UserId);

        await _repo.SaveJournalEntryAsync(entry, ct);
        await tx.CommitAsync(ct);

        return Created(string.Empty, new { status = "POSTED", entryId = entry.Id, recognizedRevenue = revenue, recognizedCogs = cogs, remainingStock = item.QtyOnHand });
    }

    public sealed record ReversalRequest(string ReversalIdempotencyKey, string Reason);

    [HttpPost("entries/{entryId:guid}/reverse")]
    public async Task<IActionResult> ReversePostedEntry(Guid entryId, [FromBody] ReversalRequest req, CancellationToken ct)
    {
        var orgId = _tenant.ActiveOrgId;
        var original = await _db.JournalEntries.Include(e => e.Lines).FirstOrDefaultAsync(e => e.Id == entryId && e.OrgId == orgId, ct);
        if (original is null) return NotFound(new { error = "JOURNAL_ENTRY_NOT_FOUND" });

        var reversal = original.CreateReversal(req.ReversalIdempotencyKey, req.Reason);
        await _repo.SaveJournalEntryAsync(reversal, ct);
        return Created(string.Empty, new { status = "REVERSED", originalEntryId = original.Id, reversalEntryId = reversal.Id });
    }
}
