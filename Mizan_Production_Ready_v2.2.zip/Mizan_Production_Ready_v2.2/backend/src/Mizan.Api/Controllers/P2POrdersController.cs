using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Mizan.Application.Services;
using Mizan.Domain.Entities;
using Mizan.Infrastructure.Persistence;
using Mizan.Infrastructure.Security;

namespace Mizan.Api.Controllers;

/// <summary>Fixes DEF-405: Real DB-backed P2P Order Submit, Inspection Release & Dispute Guard.</summary>
[ApiController]
[Authorize]
[Route("api/v1/p2p/orders")]
public sealed class P2POrdersController : ControllerBase
{
    private readonly P2PCommerceService _p2pService;
    private readonly MizanDbContext _db;
    private readonly TenantContext _tenant;

    public P2POrdersController(P2PCommerceService p2pService, MizanDbContext db, TenantContext tenant)
    {
        _p2pService = p2pService;
        _db = db;
        _tenant = tenant;
    }

    public sealed record CreateP2POrderRequest(string IdempotencyKey, Guid SellerOrgId, PaymentMode PaymentMode, string Currency, decimal TotalAmount, string? ExternalPspAuthRef, bool HasApprovedCreditLimit = false);

    [HttpPost]
    public async Task<IActionResult> CreateAndSubmitOrder([FromBody] CreateP2POrderRequest req, CancellationToken ct)
    {
        var order = new P2POrder
        {
            IdempotencyKey = req.IdempotencyKey,
            SellerOrgId = req.SellerOrgId,
            BuyerUserId = _tenant.UserId,
            BuyerOrgId = _tenant.ActiveOrgId == Guid.Empty ? null : _tenant.ActiveOrgId,
            PaymentMode = req.PaymentMode,
            Currency = req.Currency.ToUpperInvariant(),
            TotalAmount = Math.Round(req.TotalAmount, 4, MidpointRounding.AwayFromZero)
        };

        _p2pService.AuthorizeOrder(order, req.ExternalPspAuthRef, req.HasApprovedCreditLimit);
        await _db.P2POrders.AddAsync(order, ct);
        await _db.SaveChangesAsync(ct);

        return Created(string.Empty, new { orderId = order.Id, state = order.State.ToString(), paymentStatus = order.PaymentStatus.ToString(), holdExpiresAt = order.HoldExpiresAt });
    }

    [HttpPost("{orderId:guid}/release")]
    public async Task<IActionResult> ConfirmInspectionAndRelease(Guid orderId, CancellationToken ct)
    {
        var order = await _db.P2POrders.FirstOrDefaultAsync(o => o.Id == orderId, ct);
        if (order is null) return NotFound(new { error = "ORDER_NOT_FOUND" });

        _p2pService.ConfirmInspectionAndRelease(order, _tenant.UserId);
        await _db.SaveChangesAsync(ct);

        return Ok(new { orderId = order.Id, state = order.State.ToString(), paymentStatus = order.PaymentStatus.ToString(), deliveredAt = order.DeliveredAt });
    }

    [HttpPost("check-dispute-eligibility")]
    public IActionResult CheckDisputeEligibility([FromQuery] bool isPerishable, [FromQuery] int minutesSinceDelivery, [FromQuery] bool isLiveCamera)
    {
        var deliveredAt = DateTimeOffset.UtcNow.AddMinutes(-minutesSinceDelivery);
        var eligible = _p2pService.CanOpenDispute(
            new P2POrder { DeliveredAt = deliveredAt },
            new InventoryItem { IsPerishable = isPerishable },
            DateTimeOffset.UtcNow,
            isLiveCamera);

        return Ok(new { eligible, isPerishable, minutesSinceDelivery, isLiveCamera });
    }
}
