using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Mizan.Application.Features;

namespace Mizan.Api.Security;

/// <summary>
/// Server-side enforcement gate: blocks direct API calls to any feature currently disabled
/// at the Platform or Organization level (prevents bypassing UI hiding).
/// </summary>
[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
public sealed class RequireFeatureAttribute : TypeFilterAttribute
{
    public RequireFeatureAttribute(string featureKey) : base(typeof(RequireFeatureFilter))
    {
        Arguments = new object[] { featureKey };
    }

    private sealed class RequireFeatureFilter : IActionFilter
    {
        private readonly string _featureKey;
        private readonly FeatureGovernanceService _governance;

        public RequireFeatureFilter(string featureKey, FeatureGovernanceService governance)
        {
            _featureKey = featureKey;
            _governance = governance;
        }

        public void OnActionExecuting(ActionExecutingContext context)
        {
            var orgHeader = context.HttpContext.Request.Headers["X-Org-Id"].FirstOrDefault();
            if (!Guid.TryParse(orgHeader, out var orgId))
            {
                context.Result = new BadRequestObjectResult(new { error = "MISSING_OR_INVALID_ORG_HEADER" });
                return;
            }

            if (!_governance.IsEnabled(orgId, _featureKey))
            {
                context.Result = new ObjectResult(new
                {
                    error = "FEATURE_DISABLED_BY_POLICY",
                    feature = _featureKey,
                    message = "This operational module is currently turned off in your preferences or scheduled for a subsequent rollout phase."
                })
                { StatusCode = 403 };
            }
        }

        public void OnActionExecuted(ActionExecutedContext context) { }
    }
}
